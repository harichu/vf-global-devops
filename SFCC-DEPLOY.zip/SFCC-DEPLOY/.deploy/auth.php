<?php

$realm = 'Restricted area';
$error_message = '<h1 style="text-align:center;margin:50px auto;">ERROR_MESSAGE</h1>';

if (isset($_REQUEST['logout'])) {
    $_SESSION['logout'] = true;
    header('location: ./');
    exit();
}

$authenticate = false;
if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']) && isset($_SESSION['logout']) && $_SESSION['logout'] !== true)
{
 $name = $_SERVER['PHP_AUTH_USER'];
 $pass = $_SERVER['PHP_AUTH_PW'];
 $currentUser = checkAuthenticate($name,  $pass);
 if ($currentUser)
 {
  $authenticate = true;
 }
}

if ($authenticate==false)
{
 header('WWW-Authenticate: Basic realm="Restricted page enter details to continue"');
 header('HTTP/1.0 401 Unauthorized');
 $_SESSION['logout'] = false;
 die(str_replace('ERROR_MESSAGE', "Authentication failed, refresh to do it again!", $error_message));
}

function checkAuthenticate($user, $pass)
{
    $userRaw = file_get_contents(guiConfigPath);
    $userJson = json_decode($userRaw, true);
    foreach ($userJson as $u => $p) {
        if ($u === $user && $p === md5($pass)) return $u;
    }
    return false;
}
