// private scope only because I wanted to use the variable name "status"
(function () {
    var networkStatus = $('footer');
    setInterval(function () {
        if (!navigator.onLine) {
            networkStatus.attr('data-offline', 1);
        } else if (networkStatus.attr('data-offline') === '1'){
            window.location.reload();
        }
    }, 2000); // 2 seconds, made up - can't find docs to suggest interval time
})();
    
$(document).ready(function() {

    var today = function() {
        var d = new Date();
        var month = d.getMonth() + 1;
        var day = d.getDate();
        var output = d.getFullYear() + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
        return output;
    }

    var setUpdateForm = function(data) {
        var updateModal = $('#updateModal');
        updateModal.find('.renew-box').removeClass('active');
        updateModal.find('#error-box').addClass('hidden');
        updateModal.find('#success-box').addClass('hidden');
        updateModal.find('input[name="pj_code"]').val('').prop('readonly', true);
        updateModal.find('input[name="pj_name"]').val('');
        updateModal.find('input[name="pj_url"]').val('');
        updateModal.find('input[name="pj_branch"]').val('master');
        updateModal.find('input[name="pj_start_date"]').val(today());
        updateModal.find('select[name="pj_expired_day"]').val('90');
        updateModal.find('select[name="pj_status"]').val('');
        updateModal.find('select[name="pj_status"]').parent().hide();
        updateModal.find('input[name="id"]').val('');
        updateModal.find('#btn-delete').hide();
        if (data.pj_name != undefined) {
            updateModal.find('#btn-delete').show();
            updateModal.find('.renew-box').addClass('active');
            updateModal.find('input[name="pj_code"]').val(data.pj_code);
            updateModal.find('input[name="pj_name"]').val(data.pj_name);
            updateModal.find('input[name="pj_url"]').val(data.pj_url);
            updateModal.find('input[name="pj_branch"]').val(data.pj_branch);
            updateModal.find('input[name="pj_start_date"]').val(data.pj_start_date);
            updateModal.find('select[name="pj_expired_day"]').val(data.pj_expired_day);
            updateModal.find('select[name="pj_status"]').val(data.pj_status);
            updateModal.find('select[name="pj_status"]').parent().show();
            updateModal.find('input[name="id"]').val(data.id);
        }
        updateModal.find('select[name="pj_expired_day"]').trigger('change');
    }

    $("body").on('click', '.btn_add', function(event) {
        event.preventDefault();
        setUpdateForm('');
        $("#updateModal").modal({ show: true });
    });

    $("body").on('click', '.tr_edit td:not(:nth-child(1)):not(:last-child)', function(event) {
        event.preventDefault();
        var url = $(this).parent().data('href');
        $.ajax({
            crossOrigin: true,
            dataType: 'json',
            url: url,
            success: function(data) {
                // console.log(data);
                setUpdateForm(data);
            }
        });
        $("#updateModal").modal({ show: true });
    });

    $("body").on('keyup', '#pj_url', function(event) {
        var $this = $(this);
        // if ( $this.val() != "" )
        $('#pj_name').val($this.val().split("/").pop().replace(".git", ""));
    });

    Date.prototype.addDays = function(days) {
        this.setDate(this.getDate() + parseInt(days));
        return this;
    };

    $('body').on('change', '#pj_expired_day', function() {
        var expired_day = $(this).val();
        var current_date = new Date($('#pj_start_date').val());
        var expired_date = current_date.addDays(expired_day);
        var dd = expired_date.getDate();
        var mm = expired_date.getMonth() + 1;
        var yyyy = expired_date.getFullYear();
        $('#pj_expired_at').val(yyyy + '/' + (mm < 10 ? '0' : '') + mm + '/' + (dd < 10 ? '0' : '') + dd)
    });

    $('body').on('click', '#pj_expired_renew', function() {
        var $pj_start_date = $('#pj_start_date');
        if ($(this).is(':checked')) {
            $pj_start_date.data('origin', $pj_start_date.val());
            $pj_start_date.val(today());
        } else {
            $pj_start_date.val($pj_start_date.data('origin'));
        }
        $('#pj_expired_day').trigger('change');
    });


    $(document).on('click', '#btn-delete', function(e) {
        e.preventDefault();
        var result = confirm("Are you sure you want to delete?");
        if (result) {

            var $form = $(this).closest('form');
            var action = $form.attr('action');
            var formData = $form.serialize();
            var pj_id = $form.find('input[name=id]').val();
            var $error_box = $form.find('#error-box');
            var $success_box = $form.find('#success-box');
            // process the form
            $.ajax({
                    type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                    url: action, // the url where we want to POST
                    data: { act: 'delete', id: pj_id}, // our data object
                    dataType: 'json', // what type of data do we expect back from the server
                    encode: true,
                })
                // using the done promise callback
                .done(function(data) {
                    // log data to the console so we can see
                    // console.log(data);
                    if (data.status == 'ok') {
                        location.reload();
                    } else if (data.status == 'error') {
                        $error_box.find('.content').html(data.msg);
                        $error_box.removeClass('hidden');
                    }
                    // here we will handle errors and validation messages
                });
        }
    });

    // process the form
    $("body").on('submit', '#updateForm', function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var $form = $(this);
        var action = $form.attr('action');
        var $error_box = $form.find('#error-box');
        var $success_box = $form.find('#success-box');
        // get the form data
        // there are many ways to get this data using jQuery (you can use the class or id also)
        // var formData = {
        //    'name'              : $('input[name=name]').val(),
        //    'email'             : $('input[name=email]').val(),
        //    'superheroAlias'    : $('input[name=superheroAlias]').val()
        // };
        var formData = $form.serialize();
        var pj_url = $form.find('input[name=pj_url]').val();
        if (pj_url == "") {
            $error_box.find('.content').html('<strong>Error</strong>: Repo url is required!');
            $error_box.removeClass('hidden');
            return false;
        } else {
            $error_box.addClass('hidden');
        }

        // process the form
        $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: action, // the url where we want to POST
                data: formData, // our data object
                dataType: 'json', // what type of data do we expect back from the server
                encode: true,
            })
            // using the done promise callback
            .done(function(data) {
                // log data to the console so we can see
                // console.log(data);
                if (data.status == 'ok') {
                    location.reload();
                } else if (data.status == 'error') {
                    $error_box.find('.content').html(data.msg);
                    $error_box.removeClass('hidden');
                }
                // here we will handle errors and validation messages
            });
    });

});

(function($) {
    /*
     * Smooth Scroll on Pageload
     * Smooth scrolling on page load if URL have a hash
     */

    $(window).on('load', function() {
        if (window.location.hash) {
            var hash = window.location.hash;
            var target = $(hash);
            target = target.length ? target : $('[name=' + hash.slice(1) + ']');
            if (target.length) {
                setTimeout(function() {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 60
                    }, 1500, 'swing');
                }, 1000);
            }
        }
    });


    //scroll to top
    $('.scrollToTop').hide();
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.scrollToTop').fadeIn(300);
        } else {
            $('.scrollToTop').fadeOut(300);
        }
    });

    $(document).on('click', '.scrollToTop', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, 500);
        return false;
    });

    //scroll to bottom
    $(document).ready(function() {
        $('.scrollToBottom').show();
    });

    $(window).scroll(function() {
        if ($(this).scrollTop() < ($(document).height() - 100 - $(window).height())) {
            $('.scrollToBottom').fadeIn(300);
        } else {
            $('.scrollToBottom').fadeOut(300);
        }
    });

    $(document).on('click', '.scrollToBottom', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: $(document).height() }, 500);
        return false;
    });

})(jQuery);