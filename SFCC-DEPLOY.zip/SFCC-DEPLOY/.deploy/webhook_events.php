<?php require_once 'function.php';

$REQUEST_URI = $_SERVER["REQUEST_URI"];
$REQUEST_METHOD = $_SERVER["REQUEST_METHOD"];
$QUERY_STRING = $_SERVER["QUERY_STRING"];
$REQUEST_TIME = $_SERVER["REQUEST_TIME"];

$request_body = file_get_contents('php://input');
$request_data = date('Y-m-d H:i:s') . " => " . $REQUEST_URI;
if (json_encode($_GET) !== '[]') $request_data .= " => GET " . json_encode($_GET);
if (json_encode($_POST) !== '[]') $request_data .= " => POST " . json_encode($_POST);

// file_put_contents("logs.txt", $request_data . PHP_EOL, FILE_APPEND | LOCK_EX);
// exit;

function get_market($target_branch)
{
    if (strpos(strtolower($target_branch), 'eu') !== false) return 'EU';
    if (strpos(strtolower($target_branch), 'na') !== false || strpos(strtolower($target_branch), 'us') !== false || strpos(strtolower($target_branch), 'ca') !== false) return 'NA';
    return '';
}

function get_env($target_branch)
{
    if (strpos(strtolower($target_branch), 'stg') !== false || strpos(strtolower($target_branch), 'staging') !== false) return 'STG';
    if (strpos(strtolower($target_branch), 'uat') !== false) return 'UAT';
    if (strpos(strtolower($target_branch), 'sit') !== false) return 'SIT';
    return '';
}

$message = '';

if (!empty($request_body)) {
    set_error_handler("handlerException");
    try {
        $request_data .= " => REQUEST_BODY " . $request_body;
        $request_body = json_decode($request_body, true);
        $pullrequest = $request_body['pullrequest'];
        $event_type = $pullrequest['type'];

        if ($event_type === 'pullrequest') {
            $pullrequest_id = $pullrequest['id'];
            $source_branch = $pullrequest['source']['branch']['name'];
            $target_branch = $pullrequest['destination']['branch']['name'];
            $author = $pullrequest['author']['display_name'];
            $closed_by = $pullrequest['closed_by']? $pullrequest['closed_by']['display_name'] : '';
            $title = $pullrequest['title'];
            $mr_url = $pullrequest['links']['html']['href'];
            $state = strtolower($pullrequest['state']); //Return all merge requests or just those that are opened, closed, locked, or merged.
            
            //        saveLog($request_body, '$request_body');
            $isWIP = (strpos(strtolower($title), 'wip:') !== false || strpos(strtolower($title), 'draft:') !== false || strpos(strtolower($title), 'do-not-merge') !== false || strpos(strtolower($title), 'only-merge') !== false || strpos(strtolower($title), 'review') !== false || strpos(strtolower($title), 'in-review') !== false || strpos(strtolower($title), 'reviewing') !== false);

            if ($event_type === 'pullrequest' && $state === 'open' && !$isWIP) {
                $message = "> [New PR ($pullrequest_id) open by $author]" . PHP_EOL . PHP_EOL . "> $title" . PHP_EOL . PHP_EOL .  "> from ( $source_branch ) into ( $target_branch ) " . PHP_EOL . PHP_EOL . "> $mr_url";
                TelegramHelper::createFile($message, null, $pullrequest_id);
                echo $message;
            }

            if ($event_type === 'pullrequest' && $state === 'declined') {
                $message = "> [Declined PR ($pullrequest_id) by $closed_by]" . PHP_EOL . PHP_EOL . "> $title" . PHP_EOL . PHP_EOL . "> $mr_url";
                TelegramHelper::createFile(null, TelegramHelper::getRequestId($pullrequest_id), $pullrequest_id);
                echo $message;
            }

            if ($event_type === 'pullrequest' && $state === 'merged' && !$isWIP) {
                $requestId = TelegramHelper::getRequestId($pullrequest_id);
                if (!empty($requestId)) {
                    TelegramHelper::createFile(null, $requestId, $pullrequest_id);
                    sleep(1);
                }
					
                $message = "> [Merged PR ($pullrequest_id) by $closed_by]" . PHP_EOL . PHP_EOL . "> $title" . PHP_EOL . PHP_EOL . "> from ( $source_branch ) into ( $target_branch ) " . PHP_EOL . PHP_EOL . "> Please wait 1-5 (min) for the deploying..." . PHP_EOL . PHP_EOL . "> $mr_url";
                $mergedID = $pullrequest_id . rand(100,999);
                TelegramHelper::createFile($message, null, $mergedID);
            }

            if ($event_type === 'pullrequest' && $state === 'merged') {
                $env = get_env($target_branch);
				$market = get_market($target_branch);
				if (!empty($env) && !empty($market)) {
					$env = "$market-$env";
					$deployPath = str_replace('deploy.cmd', 'deploy.' . $env . '.cmd', deployPath);

					//$isDeploy = (isset($_REQUEST['deploy']) && $_REQUEST['deploy'] == 'no') ? false : true;
					//if ($isDeploy === false) continue;

					if (!file_exists($deployPath)) {
						$force = (isset($_POST['force']) && $_POST['force'] == '1') ? ' --force 1' : '';
						$compile = (isset($_POST['compile'])) ? ' --compile 1' : '';
						$cartridges = (isset($_POST['cartridges'])) ? ' --cartridges 1' : '';
						$site = (isset($_POST['site'])) ? ' --site ' . $_POST['site'] : '';
						$redeploy = (isset($_POST['redeploy'])) ? ' --redeploy ' . $_POST['redeploy'] : '';
						$env = $env . $force . $compile . $site . $cartridges . $redeploy . " --telegramid $mergedID";
						$myfile = fopen($deployPath, "w") or die("Unable to open file!");
						fwrite($myfile, $env);
						fclose($myfile);
						//if ($pusher) $pusher->trigger('vho-deploy-channel', 'vho-deploy-event', array('hasInProgress' => 1));
					}

					//$message = "$closed_by đã merge branch [$source_branch] vào [$target_branch]. Vui lòng chờ (1-5 phút) để hệ thống deploy.... oOo" . PHP_EOL . PHP_EOL . "$mr_url";
					//TelegramHelper::createFile(null, TelegramHelper::getRequestId($pullrequest_id), $pullrequest_id);
					TeamsIncomingWebhookHelper::sendMessage($message);
					die($message);
				}
            }
            exit();
        }
        if ($event_type === 'push') {
            $user_username = $request_body['user_username'];
            //if ($user_username !== 'haicv') exit();

            $target_branch = str_replace('refs/heads/', '', $request_body['ref']);
            $source_branch = array('isVF' => false,'isVHO' => false);
            $commits = $request_body['commits'];
            if (count($commits)) {
                foreach ($commits as $commit) {
                    $added = $commit['added'];
                    $modified = $commit['modified'];
                    $removed = $commit['removed'];
                    if (count($added)) {
                        foreach ($added as $item) {
                            if (strpos($item, 'storefront-vinfast-vn') !== false) $source_branch['isVF'] = true;
                            if (strpos($item, 'storefront-leasing-vn') !== false) $source_branch['isVHO'] = true;
                        }
                    }
                    if (count($modified)) {
                        foreach ($modified as $item) {
                            if (strpos($item, 'storefront-vinfast-vn') !== false) $source_branch['isVF'] = true;
                            if (strpos($item, 'storefront-leasing-vn') !== false) $source_branch['isVHO'] = true;
                        }
                    }
                    if (count($removed)) {
                        foreach ($removed as $item) {
                            if (strpos($item, 'storefront-vinfast-vn') !== false) $source_branch['isVF'] = true;
                            if (strpos($item, 'storefront-leasing-vn') !== false) $source_branch['isVHO'] = true;
                        }
                    }
                }
            }

            if ($source_branch['isVF'] === false && $source_branch['isVHO'] === false) $source_branch = 'staging';
            else if ($source_branch['isVF'] === true) $source_branch = 'VFCOM-';
            else if ($source_branch['isVHO'] === true) $source_branch = 'VFMCOM-';

            $orgs = array();
            if (isOrgName($source_branch, $org_vf)) {
                $orgs[] = $org_vf;
            }
            if (isOrgName($source_branch, $org_vho)) {
                $orgs[] = $org_vho;
            }
            if (count($orgs) === 0) {
                $orgs = array($org_vf, $org_vho);
            }

            foreach ($orgs as $org) {
                $env = get_env($target_branch);
                $env = $env . '-' . $org;
                $env = str_replace('DEMO-VF','DEMO', $env);
                $deployPath = str_replace('deploy.cmd', 'deploy.' . $env . '.cmd', deployPath);

                if (!file_exists($deployPath)) {
                    $force = (isset($_POST['force']) && $_POST['force'] == '1') ? ' --force 1' : '';
                    $compile = (isset($_POST['compile'])) ? ' --compile 1' : '';
                    $cartridges = (isset($_POST['cartridges'])) ? ' --cartridges 1' : '';
                    $site = (isset($_POST['site'])) ? ' --site ' . $_POST['site'] : '';
                    $redeploy = (isset($_POST['redeploy'])) ? ' --redeploy ' . $_POST['redeploy'] : '';
                    $env = $env . $force . $compile . $site . $cartridges . $redeploy;
                    $myfile = fopen($deployPath, "w") or die("Unable to open file!");
                    fwrite($myfile, $env);
                    fclose($myfile);
                    if ($pusher) $pusher->trigger('vho-deploy-channel', 'vho-deploy-event', array('hasInProgress' => 1));
                }
            }
            $message = "Deploying to [$target_branch]...";
            die($message);
            exit();
        }
    } catch (Exception $e) {
        saveLog(handlerExceptionMessage($e), 'webhook_events');
    }
    restore_error_handler();
}
