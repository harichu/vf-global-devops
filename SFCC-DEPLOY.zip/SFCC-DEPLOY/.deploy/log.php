<?php require_once 'function.php'; require_once 'auth.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';
$logFile = isset($_GET['file']) ? $_GET['file'] : '';

if ($action === 'list'){
    $log_list = get_log_list();
    if (count($log_list)){
        foreach($log_list as $file):
            echo '<li class="list-group-item"><a data-file="'.$file['name'].'" href="?log='.$file['name'].'">'.$file['name'].'</a><span class="badge badge-primary badge-pill">'.$file['size'].'</span></li>';
        endforeach;
    } else {
        echo '';
    }
    exit;
}


if ($action === 'detail'){
    if ($logFile && file_exists(LOG_PATH . '/' . $logFile)){
        $deployResult = file_get_contents(LOG_PATH . '/' . $logFile);
        $deployResult = "<pre>" . format_result($deployResult) . "</pre>" ;
        echo $deployResult;
    }
    exit;
}