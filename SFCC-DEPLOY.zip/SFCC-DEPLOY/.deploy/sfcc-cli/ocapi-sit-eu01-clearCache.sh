#!/bin/bash

command -v jq >/dev/null 2>&1 || { echo >&2 "jq is required, but it's not installed.  installing....."; sudo apt-get install jq -y; }

SANDBOX_URL=bhgw-010.sandbox.us01.dx.commercecloud.salesforce.com
CLIENT_ID=5cda7bac-7866-4bed-b6c9-fdd328838ebc
BASIC_AUTH='di5vbmxpbmUuYXBpLnVhdEBob3RtYWlsLnJlZDo2clY9d3N0VStiXyV4MStUSyMvZiloMzNZK1JqVndNJWFMYWdwbGMjOjViYjg5NzJkNDM='

access_token=`curl -s --location --request POST "https://${SANDBOX_URL}/dw/oauth2/access_token?client_id=${CLIENT_ID}" --header 'Content-Type: application/x-www-form-urlencoded' --header "Authorization: Basic ${BASIC_AUTH}" --data-urlencode 'grant_type=urn:demandware:params:oauth:grant-type:client-id:dwsid:dwsecuretoken' | jq -r '.access_token'`

#echo "access_token=$access_token"


job_lists=( "ClearCache" )
for job_id in "${job_lists[@]}"
do

    duration=`curl -s --location --request POST "https://${SANDBOX_URL}/s/-/dw/data/v21_10/jobs/${job_id}/executions" --header 'Content-Type: application/json' --header "Authorization: Bearer $access_token" | jq -r '.duration'`
    echo "run job ${job_id} / duration: ${duration}"

done


# echo $access_token