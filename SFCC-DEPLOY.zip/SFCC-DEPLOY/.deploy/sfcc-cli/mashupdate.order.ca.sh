#!/bin/bash

curl -s -L -X POST 'https://shop.vinfastauto.us/on/demandware.store/Sites-Vinfast-CA-Site/default/Console-Run' \
-H 'Authorization: Basic di5oYWljdjNAdmluZmFzdC52bjpWaG1AMTIzNDU=' \
-H 'Content-Type: application/javascript' \
--data-raw 'var collections = require('\''*/cartridge/scripts/util/collections'\'');
var Money = require('\''dw/value/Money'\'');
var priceFactory = require('\''*/cartridge/scripts/factories/price'\'');
var PromotionMgr = require('\''dw/campaign/PromotionMgr'\'');
var Transaction = require('\''dw/system/Transaction'\'');
var OrderMgr = require('\''dw/order/OrderMgr'\'');
const Order = require('\''dw/order/Order'\'');
var ProductMgr = require('\''dw/catalog/ProductMgr'\'');
var HookMgr = require('\''dw/system/HookMgr'\'');
var PaymentInstrument = require('\''dw/order/PaymentInstrument'\'');
var currentLocale = request.locale;
var customerHelpers = require('\''*/cartridge/scripts/helpers/customerHelpers'\'');

const customerEmail = '\''lussier.alain@hotmail.com'\'';
const orderID = '\'''\'';
const orderToken = '\'''\'';
var order = (orderToken) ? OrderMgr.getOrder(orderID, orderToken) : OrderMgr.getOrder(orderID);
if (empty(order)) order = OrderMgr.searchOrder('\''custom.storefrontOrderID={0}'\'', orderID);
// return customerHelpers.getCustomerServiceCloudByEmail(customerEmail);

var orderUpdatedListCnt = 0, orderUpdatedList = [];
Transaction.wrap(function () {
    var order, orders = OrderMgr.searchOrders('\''customerNo = NULL AND (status = {0} OR status = {1} OR status = {2} OR status = {3})'\'', '\''creationDate DESC'\'', Order.ORDER_STATUS_NEW, Order.ORDER_STATUS_OPEN, Order.ORDER_STATUS_COMPLETED, Order.ORDER_STATUS_CANCELLED);
    orderUpdatedListCnt = orders.count;
    while (orders.hasNext() && orderUpdatedList.length < 2) {
        order = orders.next();
        var setCustomer = customerHelpers.createCustomerByEmail(order.customerEmail, order.billingAddress.lastName, order.billingAddress.firstName, { phone: order.billingAddress.phone, zipCode: order.billingAddress.postalCode });
        order.setCustomer(setCustomer);
        orderUpdatedList.push(order.orderNo);
    }
});
//if (orderUpdatedListCnt === orderUpdatedList.length) 
return [orderUpdatedListCnt, orderUpdatedList];

Transaction.wrap(function () {
    if (order) {
        order.setCustomer(customer);
        // if (empty(order.custom.readyForOrderConversion)) {
        // order.custom.readyForOrderConversion = true;
        // order.custom.isReservationApplied = false;
        // order.setPaymentStatus(require('\''dw/order/Order'\'').PAYMENT_STATUS_PAID);
        // }
    }
});

return order ? {
    orderNumber: order.orderNo,
    storefrontOrderID: order.custom.storefrontOrderID,
    readyForOrderConversion: order.custom.readyForOrderConversion,
    serviceCloudOrderId: order.custom.serviceCloudOrderId
} : '\''order ('\'' + orderID + '\'') not found'\'';
'