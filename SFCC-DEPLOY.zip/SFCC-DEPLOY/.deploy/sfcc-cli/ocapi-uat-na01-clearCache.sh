#!/bin/bash

command -v jq >/dev/null 2>&1 || { echo >&2 "jq is required, but it's not installed.  installing....."; sudo apt-get install jq -y; }

SANDBOX_URL=development-na01-vinfast.demandware.net
CLIENT_ID=5cda7bac-7866-4bed-b6c9-fdd328838ebc
BASIC_AUTH='c2ZjYy5pbnRlZ3JhdGlvbkB2aW5mYXN0LmV1Lm9yZzozYlI9K2JTQnp2OS4uWjctX3slKmlabnFiUUdGKHIsbnd1RUk4OXh1OjViYjg5NzJkNDMK'

access_token=`curl -s --location --request POST "https://${SANDBOX_URL}/dw/oauth2/access_token?client_id=${CLIENT_ID}" --header 'Content-Type: application/x-www-form-urlencoded' --header "Authorization: Basic ${BASIC_AUTH}" --data-urlencode 'grant_type=urn:demandware:params:oauth:grant-type:client-id:dwsid:dwsecuretoken' | jq -r '.access_token'`

# echo "access_token=$access_token"


job_lists=( "ClearCache" )
for job_id in "${job_lists[@]}"
do

    duration=`curl -s --location --request POST "https://${SANDBOX_URL}/s/-/dw/data/v21_10/jobs/${job_id}/executions" --header 'Content-Type: application/json' --header "Authorization: Bearer $access_token" | jq -r '.duration'`
    echo "run job ${job_id} / duration: ${duration}"

done


# echo $access_token