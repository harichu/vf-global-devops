<?php require_once 'function.php';


if ($act === 'success' && $file) {
    $filePath = LOG_PATH . '/' . $file . '.txt';
    if (file_exists($filePath)) {
        $deployResult = file_get_contents($filePath);
        
        $re = '/\[1;32m> git branch: \[0m\[\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m\]/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $gitBranch = $matches[0][1] ?? '';
        
        $re = '/\[1;32m> code version: \[0m\[\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m\]/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $codeVersion = $matches[0][1] ?? '';
        
        $re = '/\[1;32m> sandbox: \[0m\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $sandbox = $matches[0][1] ?? '';
        
        if ($gitBranch && $codeVersion && $sandbox) {
            $message = "> Deploy successfully" . PHP_EOL . PHP_EOL .  "> git branch: $gitBranch" . PHP_EOL . PHP_EOL .  "> code version: $codeVersion" . PHP_EOL . PHP_EOL .  "> sandbox: $sandbox";
            echo $message;
            $sendMessageResult = TeamsIncomingWebhookHelper::sendMessage($message);
        }
    }
    exit;
}


$message = isset($_REQUEST['message'])? $_REQUEST['message'] : '';
if (!empty($message)) {
    TeamsIncomingWebhookHelper::sendMessage($message);
}