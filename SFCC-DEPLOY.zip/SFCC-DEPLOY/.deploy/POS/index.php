<?php
$envs = array(
    'sit' =>  array(
        'us' => array(
            'reader_id' => 'tmr_FGzw1AU330aB7l',
            'auth' => 'sk_test_51N5g34H3FXAzg4PiZ3NOXXhQICL0E1uJADy0HG6vfKqIx4RMVX9DxSCwHGRLwsOTJ7cj0tM13e0VCHYXP0beN8dV00kYyBuSal'
        ),
        'ca' => array(
            'reader_id' => 'tmr_FGz3KALw6hGvju',
            'auth' => 'sk_test_51NBqDNCjURjdh3prrX8swIMnA19y97rTkY21m0kSujOFCEkyKhK5hwJw8h3SLztQpAQHDOrgEY7XX2PJYFy0xuwW00shfNgIEh'
        )
    ),
    'uat' =>  array(
        'us' => array(
            'reader_id' => 'tmr_FJ0V7QI0XrOoDp',
            'auth' => 'sk_test_51N5g34H3FXAzg4PiZ3NOXXhQICL0E1uJADy0HG6vfKqIx4RMVX9DxSCwHGRLwsOTJ7cj0tM13e0VCHYXP0beN8dV00kYyBuSal'
        ),
        'ca' => array(
            'reader_id' => 'tmr_FG6KWQ2WWa2199',
            'auth' => 'sk_test_51NBqDNCjURjdh3prrX8swIMnA19y97rTkY21m0kSujOFCEkyKhK5hwJw8h3SLztQpAQHDOrgEY7XX2PJYFy0xuwW00shfNgIEh'
        )
    )
);

$market_cmd = isset($_POST['market_cmd']) ? $_POST['market_cmd'] : 'SIT-US-SUCCESS';
$cmd_result = '';

if (isset($_POST['market_cmd'])) {
    $cmdPie = explode('-', strtolower($market_cmd));
    $card_type = (isset($cmdPie[3]) && $cmdPie[3] == 'interac')? 'interac_present' : 'card_present';
    $cmd_result = ($cmdPie[2] === 'success')? run_success($cmdPie[0], $cmdPie[1], $card_type) : run_failed($cmdPie[0], $cmdPie[1], $card_type);
}

function run_success($env, $country, $card_type = 'card_present') {
    global $envs, $reader_id, $auth_key;
    $reader_id = $envs[$env][$country]['reader_id'];
    $auth_key = $envs[$env][$country]['auth'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/test_helpers/terminal/readers/'.$reader_id.'/present_payment_method');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $auth_key,
    ]);
    if ($card_type === 'interac_present') curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=interac_present');
    else curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card_present');
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        return 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    return $response;
}

function run_failed($env, $country, $card_type = 'card_present') {
    global $envs, $reader_id, $auth_key;
    $reader_id = $envs[$env][$country]['reader_id'];
    $auth_key = $envs[$env][$country]['auth'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/test_helpers/terminal/readers/'.$reader_id.'/present_payment_method');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $auth_key,
        'Content-Type: application/x-www-form-urlencoded',
    ]);
    if ($card_type === 'interac_present') curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=interac_present&interac_present[number]=4000000000000002');
    else curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card_present&card_present[number]=4000000000000002');
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        return 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    return $response;
}
?>

<!DOCTYPE html>
<html lang='en' class=''>

<head>

  <meta charset='UTF-8'>
  <title>(VinFast) Stripe Simulator Test</title>

  <meta name="robots" content="noindex">

 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">

  <style id="INLINE_PEN_STYLESHEET_ID">
    @import url("https://fonts.googleapis.com/css?family=Open+Sans:400,700");
@import url("https://fonts.googleapis.com/css?family=Pacifico");
body {
  background: #e0e0e0;
  font-family: "Open Sans", sans-serif;
  font-size: 14px;
  line-height: 21px;
  padding: 15px 0;
}

h1 {
  color: #333;
  font-family: "Pacifico", cursive;
  font-size: 28px;
  line-height: 42px;
  margin: 0 0 15px;
  text-align: center;
}

.content {
  background: #fff;
  border-radius: 3px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075), 0 2px 4px rgba(0, 0, 0, 0.0375);
  padding: 30px 30px 20px;
}

.form-control {
  border: 1px solid #ccc;
  border-radius: 3px;
  box-shadow: none;
  margin-bottom: 15px;
}
.form-control:hover, .form-control:focus, .form-control:active {
  box-shadow: none;
}
.form-control:focus {
  border: 1px solid #34495e;
}

.select2.select2-container {
  width: 100% !important;
}

.select2.select2-container .select2-selection {
  border: 1px solid #ccc;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  height: 34px;
  margin-bottom: 15px;
  outline: none;
  transition: all 0.15s ease-in-out;
}

.select2.select2-container .select2-selection .select2-selection__rendered {
  color: #333;
  line-height: 32px;
  padding-right: 33px;
}

.select2.select2-container .select2-selection .select2-selection__arrow {
  background: #f8f8f8;
  border-left: 1px solid #ccc;
  -webkit-border-radius: 0 3px 3px 0;
  -moz-border-radius: 0 3px 3px 0;
  border-radius: 0 3px 3px 0;
  height: 32px;
  width: 33px;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--single {
  background: #f8f8f8;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--single .select2-selection__arrow {
  -webkit-border-radius: 0 3px 0 0;
  -moz-border-radius: 0 3px 0 0;
  border-radius: 0 3px 0 0;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--multiple {
  border: 1px solid #34495e;
}

.select2.select2-container.select2-container--focus .select2-selection {
  border: 1px solid #34495e;
}

.select2.select2-container .select2-selection--multiple {
  height: auto;
  min-height: 34px;
}

.select2.select2-container .select2-selection--multiple .select2-search--inline .select2-search__field {
  margin-top: 0;
  height: 32px;
}

.select2.select2-container .select2-selection--multiple .select2-selection__rendered {
  display: block;
  padding: 0 4px;
  line-height: 29px;
}

.select2.select2-container .select2-selection--multiple .select2-selection__choice {
  background-color: #f8f8f8;
  border: 1px solid #ccc;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  margin: 4px 4px 0 0;
  padding: 0 6px 0 22px;
  height: 24px;
  line-height: 24px;
  font-size: 12px;
  position: relative;
}

.select2.select2-container .select2-selection--multiple .select2-selection__choice .select2-selection__choice__remove {
  position: absolute;
  top: 0;
  left: 0;
  height: 22px;
  width: 22px;
  margin: 0;
  text-align: center;
  color: #e74c3c;
  font-weight: bold;
  font-size: 16px;
}

.select2-container .select2-dropdown {
  background: transparent;
  border: none;
  margin-top: -5px;
}

.select2-container .select2-dropdown .select2-search {
  padding: 0;
}

.select2-container .select2-dropdown .select2-search input {
  outline: none;
  border: 1px solid #34495e;
  border-bottom: none;
  padding: 4px 6px;
}

.select2-container .select2-dropdown .select2-results {
  padding: 0;
}

.select2-container .select2-dropdown .select2-results ul {
  background: #fff;
  border: 1px solid #34495e;
}

.select2-container .select2-dropdown .select2-results ul .select2-results__option--highlighted[aria-selected] {
  background-color: #3498db;
}

.select2-container--default .select2-results>.select2-results__options {
    max-height: 400px;
}

.select2-container .select2-dropdown .select2-results__option[role="group"] {
    padding-left: 10px;
    padding-right: 10px;
}

.btn-submit {
    width: 100%;
}

.alert-info {
    white-space: nowrap;
    overflow: auto;
}

.alert-info::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 3px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.alert-info::-webkit-scrollbar
{
	width: 3px !important;
	background-color: #F5F5F5;
}

.alert-info::-webkit-scrollbar-thumb
{
	background-color: #000000;
}

.alert-danger pre {
    background-color: #f2dede;
    border: none;
    color: #a94442;
    word-break: unset;
    word-wrap: unset;
    white-space: break-spaces;
    overflow: unset;
}
.alert-success pre {
    background-color: #dff0d8;
    border: none;
    color: #3c763d;
    word-break: unset;
    word-wrap: unset;
    white-space: break-spaces;
    overflow: unset;
}
  </style>
 <link rel="shortcut icon" href="https://www.svgrepo.com/show/331592/stripe-v2.svg">
</head>

<body>
<form method="POST" action="">
  <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="content d-flex">
            <h1>(VinFast) Stripe Simulator Test</h1>
            <div class="row">
              <div class="col-md-10">
                <select class="js-select2" name="market_cmd">
                <?php foreach ($envs as $envKey => $env): ?>
                    <?php foreach ($env as $marketKey => $market): ?>
                      <optgroup label="<?php echo strtoupper("$envKey ➤ $marketKey");?>">
                        <option value="<?php echo strtoupper("$envKey-$marketKey-SUCCESS");?>" <?php echo (strtoupper("$envKey-$marketKey-SUCCESS") === $market_cmd)? 'selected':'';?>><?php echo strtoupper("$envKey $marketKey SUCCESS") . ' &nbsp&nbsp&nbsp&nbsp (' . $market['reader_id'] . ')';?></option>
                        <option value="<?php echo strtoupper("$envKey-$marketKey-FAIL");?>" <?php echo (strtoupper("$envKey-$marketKey-FAIL") === $market_cmd)? 'selected':'';?>><?php echo strtoupper("$envKey $marketKey FAIL") . ' &nbsp&nbsp&nbsp&nbsp (' . $market['reader_id'] . ')';?></option>
                      

                      <?php if ($marketKey == 'ca'):?>
                            <option disabled>-----------------------------------------------------------</option>
                            <option value="<?php echo strtoupper("$envKey-$marketKey-SUCCESS-interac");?>" <?php echo (strtoupper("$envKey-$marketKey-SUCCESS-interac") === $market_cmd)? 'selected':'';?>><?php echo strtoupper("$envKey $marketKey SUCCESS ➜ interac") . ' &nbsp&nbsp&nbsp&nbsp (' . $market['reader_id'] . ')';?></option>
                            <option value="<?php echo strtoupper("$envKey-$marketKey-FAIL-interac");?>" <?php echo (strtoupper("$envKey-$marketKey-FAIL-interac") === $market_cmd)? 'selected':'';?>><?php echo strtoupper("$envKey $marketKey FAIL ➜ interac") . ' &nbsp&nbsp&nbsp&nbsp (' . $market['reader_id'] . ')';?></option>
                      <?php endif;?>
                      </optgroup>
                    <?php endforeach;?>
                <?php endforeach;?>
                </select>
              </div>
              <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-submit">RUN</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php if ($cmd_result): ?>
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="content" style="padding-top:0">
                 <div class="alert alert-info" role="alert">
                    <p>Reader ID: <strong><?php echo $reader_id;?></strong></p>
                    <p>Authorization: Bearer <strong><?php echo $auth_key;?></strong></p>
                </div>
                <?php $cmd_result_obj = json_decode($cmd_result, true); ?>
                <?php $isSuccess = isset($cmd_result_obj['status']); ?>
                <?php if (!$isSuccess): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo '<pre>' . $cmd_result . '</pre>';?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo '<pre>' . $cmd_result . '</pre>';?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
</form>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>
<script>
    $(document).ready(function() {
  $(".js-select2").select2();
});
</script>
</body>

</html>