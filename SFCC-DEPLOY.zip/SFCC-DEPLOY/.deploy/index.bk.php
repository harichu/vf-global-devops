﻿<?php require_once 'function.php'; require_once 'auth.php'; get_csrf(); $env = (isset($_GET['env'])? $_GET['env'] : 'SIT'); $org = (isset($_GET['org'])? $_GET['org'] : 'NA');?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>🚀 [Global] SFCC.DEPLOY</title>
        <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <link rel="stylesheet" href="./assets/css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" href="./assets/css/font-awesome.min.css" media="screen" />
        <link rel="stylesheet" href="./assets/css/styles.css?999" media="screen" />
        <link rel="shortcut icon" href="./assets/img/favicon.ico" />
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries https://cdn.dribbble.com/users/1431278/screenshots/3341394/trump_runner1.gif -->
        <!--[if lt IE 9]>
            <script src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
        #deploy_queue_list {
            background: transparent;
            border: none;
        }
        </style>
    </head>
    <body style="background: url('./assets/img/be832922391491.58c25558f0fe7.gif') center center no-repeat; background-size: cover; background-attachment: fixed; overflow-x: hidden;">
        <?php if (@$currentUser): ?>
            <div class="logout"><a href="?logout" class="btn btn-danger btn-xs">Logout?</a></div>
        <?php endif; ?>
        <div id="pressDeployBtn">
              <div class="form">
                 <div class="form-group">
                    <label>Environment</label>
                    <?php $ENV_LIST = array(
                      'SIT' => array( 'color' => '#514f4d' ),
                      'UAT' => array( 'color' => '#64772d' ),
                      'STG' => array( 'color' => '#cb333b' )
                    );
                    if ($name !== 'stg') unset($ENV_LIST['STG']);
                    ?>
                    <select class="form-control" name="ENV">
                        <?php foreach ($ENV_LIST as $ENV => $envObj): ?>
                            <optgroup label="Environment" style="color: #fff; background-color: <?php echo $envObj['color'];?>">
                                <option value="<?php echo $ENV;?>" <?php echo ($ENV === $env)? 'selected' : '';?>><?php echo $ENV;?></option>
                                <?php if ($ENV === 'SIT' && $name === 'stg'): ?>
                                    <option value="<?php echo "{$ENV}2";?>" <?php echo ("{$ENV}2" === $env)? 'selected' : '';?>><?php echo "{$ENV} (2)";?></option>
                                    <option value="<?php echo "{$ENV}-TCS";?>" <?php echo ("{$ENV}-TCS" === $env)? 'selected' : '';?>><?php echo "{$ENV} (TCS)";?></option>
                                <?php endif; ?>
                            </optgroup>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                  <label>Market</label>
                  <select class="form-control" name="ORG">
                    <option value="NA" <?php echo ('NA' === $org)? 'selected' : '';?>>North America</option>
                    <option value="EU" <?php echo ('EU' === $org)? 'selected' : '';?>>European</option>
                  </select>
                </div>
              </div>
              <div class="deployButton"><img src="./assets/img/deployment-icon-24.png" alt="" /></div>
              <input type="text" name="commitId" class="form-control" placeholder="commit SHA" style="display: none">
        </div>

        <?php
        $logFile = (isset($_GET['log']) && $_GET['log']) ? $_GET['log'] : '';
        if ($logFile && file_exists(LOG_PATH . '/' . $logFile)){
            $deployResult = file_get_contents(LOG_PATH . '/' . $logFile);
            $deployResult = "<pre>" . format_result($deployResult) . "</pre>" ;
        }
        ?>
        <div class="mainWrapper">
            <div class="container hover">
                <div id="deploy_results_loc"></div>
                <div class="panel panel-success" id="deploy_results" style="<?php echo (@$deployResult)? '' : 'display: none;';?>">
                    <div class="panel-heading">
                        <h3 class="panel-title clearfix">
                            <div class="pull-left"><i class="fa fa-cloud-download" aria-hidden="true"></i> Deploy Results</div>
                        </h3>
                    </div>
                    <div class="panel-body table-responsive"><?php echo @$deployResult;?></div>
                </div>
            </div>
            
            <?php
                $deploy_queue_list = get_deploy_queue_list(999, 0, true);
            ?>
            <div class="panel panel-warning" id="deploy_queue_list" style="<?php echo (count($deploy_queue_list))? '' : 'display: none;';?>">
                <img id="imgDeployFailed" src="./assets/img/drunk9.gif" style="display: none; width: 300px;margin: 0 auto;">
                <div class="panel-heading">
                    <h3 class="panel-title clearfix">
                        <i class="fa fa-list" aria-hidden="true"></i> Deploy queue list (<span id="deploy_queue_list_cnt"><?php echo count($deploy_queue_list);?></span>)
                    </h3>
                </div>
                <div id="deploy_queue_list_collapse" class="panel-body table-responsive panel-collapse collapse">
                    <ul class="list-group" id="deploy_queue_list_ul">
                    <?php if (count($deploy_queue_list)): foreach($deploy_queue_list as $file): ?>
                      <?php $statusIcon = (($file['status'] === 'done')? '' : (($file['status'] === 'inprogress')? '<i class="fa fa-spinner fa-spin" aria-hidden="true"></i> ' : '<i class="fa fa-hourglass-half" aria-hidden="true"></i> ')); ?>
                        <li class="list-group-item"><a data-file="<?php echo $file['name'];?>" href="?log=<?php echo $file['name'];?>.txt"><?php echo $file['name'];?></a><span class="badge badge-pill <?php echo (($file['status'] === 'done')? 'bg-success' : (($file['status'] === 'inprogress')? 'bg-danger':'bg-secondary'));?>"><?php echo $statusIcon;?><?php echo $file['status'];?></span></li>
                    <?php endforeach; endif; ?>
                    </ul>
                </div>
                <a data-toggle="collapse" id="deploy_queue_list_collapse_a" href="#deploy_queue_list_collapse"></a>
            </div>
            
            <?php
                $log_list = get_log_list();
                if (count($log_list)):
            ?>
            <div class="panel-group" id="panel-logs">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      Logs
                    </h4>
                  </div>
                  <div id="collapse1" class="panel-collapse collapse">
                    <ul class="list-group" id="log-list">
                    <?php foreach($log_list as $file): ?>
                      <li class="list-group-item"><a data-file="<?php echo $file['name'];?>" href="?log=<?php echo $file['name'];?>"><?php echo $file['name'];?></a><span class="badge badge-primary badge-pill"><?php echo $file['size'];?></span></li>
                    <?php endforeach; ?>
                    </ul>
                    <div class="panel-footer">Logs</div>
                  </div>
                </div>
                <a data-toggle="collapse" id="panel_log_collapse_a" style="display:none" href="#collapse1"></a> 
            </div>
            <?php
                endif;
            ?>
            
        </div>

        <footer class="footer">
            <div class="container">
                <div class="row col-sm-12">
                    <p class="text-muted">Powered by © haicv3@SFDC.</p>
                </div>
            </div>
        </footer>
        
        <div style="opacity: 0;visibility: hidden;position: fixed;bottom: -1000px;left: -1000px;">
          <?php
          $running = 'mario-running.gif';
          $runningArr = ['mario-running.gif'];
          shuffle($runningArr);
          $running = $runningArr[0];
          ?>
        <img src="./assets/img/<?php echo $running;?>" />
        </div>

        <div class="bird-container bird-container--one"><div class="bird bird--one"></div></div>
        <div class="bird-container bird-container--two"><div class="bird bird--two"></div></div>
        <div class="bird-container bird-container--three"><div class="bird bird--three"></div></div>
        <div class="bird-container bird-container--four"><div class="bird bird--four"></div></div>

        <audio id="audio-success" src="audio/successfully.mp3" preload="auto"></audio>
        <audio id="audio-go-cua" src="audio/go-cua.mp3" preload="auto"></audio>

        <audio id="audio-nam" src="audio/nam-oi.mp3" preload="auto"></audio>
        <audio id="audio-quaqua" src="audio/tieng-qua-keu.mp3" preload="auto"></audio>
        <audio id="audio-soi-hu" src="audio/tieng-soi-hu.mp3" preload="auto"></audio>
        <audio id="audio-dan-cho-sua" src="audio/dan-cho-sua.mp3" preload="auto"></audio>
        <audio id="audio-ga-cuc-tac" src="audio/ga-cuc-tac.mp3" preload="auto"></audio>
        <audio id="audio-tieng-de-keu" src="audio/tieng-de-keu.mp3" preload="auto"></audio>

        <script src="./assets/js/jquery-1.12.4.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="./assets/push.js/push.min.js"></script>
        <script type="text/javascript" src="./assets/js/pusher.min.js"></script>
        <!-- define the project's URL (to make AJAX calls possible, even when using this in sub-folders etc) -->
        <script>
          var url = "./";
          window.csrf = { csrf_token: '<?php echo $_SESSION['csrf_token']; ?>' };
          $.ajaxSetup({
              data: window.csrf
          });
        </script>
        <script src="./assets/js/setting.js?date=20200616"></script>
        <script>
            function randomRunningMan(){
                var runningArr = ["<?php echo implode('","', $runningArr);?>"];
                return runningArr[(Math.random() * runningArr.length) | 0];
            }
            $(document).ready(function () {
                $('[data-toggle="tooltip"]').tooltip();
                $(window).on("load resize", function () {
                    var $mainWrapper = $(".mainWrapper");
                    if ($mainWrapper.outerHeight() > $(window).height() - 62) {
                        $mainWrapper.css({ "padding-top": 15, "padding-bottom": 15 });
                    }
                });
                $(".pagination").on("click", ".page-item.disabled", function (event) {
                    event.preventDefault();
                });
            });
            function containsWord(haystack, needle) {
                return ("" + haystack + "").indexOf("" + needle + "") !== -1;
            }
            function show_hide_run_git_cmd() {
                var cocomachi_cmd_el = $(".cocomachi_cmd");
                cocomachi_cmd_el.toggle();
            }
            function changeTitle(title) {
                var orgin_title = "[Global] SFCC.DEPLOY";
                document.title = title;
                setTimeout(function () {
                    document.title = orgin_title;
                }, 10000);
            }
            function open_window(url, title, width, height) {
                var my_window;
                if (url == "") url = "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQ9R-a__MCVgMpFAvmpAlcJA__pCFAaXuIkhIEypi0bXUs6D0_VsQ";
                if (title == "") title = "Windows";
                if (width == "") width = 204;
                if (height == "") height = 190;
                // screen.width means Desktop Width
                // screen.height means Desktop Height

                var center_left = screen.width / 2 - width / 2;
                var center_top = screen.height / 2 - height / 2;

                my_window = window.open(url, title, "directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no, width=" + width + ", height=" + height + ", left=" + center_left + ", top=" + center_top);
                my_window.focus();
                setTimeout(function () {
                    my_window.focus();
                }, 1000);
            }
            function strip(html) {
                var tmp = document.createElement("DIV");
                tmp.innerHTML = html;
                return tmp.textContent || tmp.innerText || "";
            }

            function push(push_title, push_content) {
                Push.create(push_title, {
                    serviceWorker: './assets/push.js/serviceWorker.js', // Sets a custom service worker script
                    timeout: 10000,
                    body: strip(push_content),
                    icon: {
                        x16: "./assets/img/favicon.png",
                        x32: "./assets/img/favicon.png",
                    },
                    vibrate: [200, 100, 200, 100, 200, 100, 200],
                    onClick: function () {
                        window.focus();
                        this.close();
                    }
                });
            }
            /* PLAY SOUND FUNCTION */
            function playAudio(file) {
                if (document.getElementById("audio-" + file) != null) document.getElementById("audio-" + file).play();
            }
            function stopAudio(file) {
                var audioElement = document.getElementById("audio-" + file);
                if (audioElement != null) {
                    audioElement.pause();
                    audioElement.currentTime = 0;
                }
            }

            jQuery(function () {
                var url_root = ".";
                var temp_load = '<div id="temp_load" style="text-align:center"><img src="./assets/img/'+randomRunningMan()+'" /></div>';
                var $results = $("#deploy_results .panel-body");
                var git_cmd_running = false;

                function parseDeployResult(result) {
                  try {
                    return JSON.parse(result);
                  } catch (e) {
                    return { 'status': '', 'data': '', 'deployQueue': { 'total': -1, 'html': '', 'hasInProgress': false} }
                  }
                }

                function selectENV(){
                    var env = $("select[name=ENV]").val();
                    if (env === 'UAT' || env === 'STG') {
                      $('select[name=ORG]').prop('disabled', false);
                    }
                }

                function changeAddressURL(){
                    var env = $('select[name=ENV] option:selected').val();
                    var org = $('select[name=ORG] option:selected').val();
                    var urlPath = url_root + "/?env=" + env + "&org=" + org;
                    window.history.pushState({}, document.title , urlPath);
                }

                $("body").on("change", "select[name=ORG]", function (e) {
                    changeAddressURL();
                });

                selectENV();
                $("body").on("change", "select[name=ENV]", function (e) {
                    selectENV();
                    changeAddressURL();
                });

                $("body").on("click", ".deployButton img", function (e) {
                    var git_cmd_running2 = git_cmd_running;
                    /*if (git_cmd_running) {
                        return false;
                    }*/
                    $("html, body").stop().animate({ scrollTop: $("#deploy_results_loc").offset().top}, 500);
                    var url_run = url_root + "/deploy-" + Date.now() + ".php";
                    var data = { action: 'DEPLOY' };
                    var selectENV =  $('select[name=ENV] option:selected');
                    var commitIdEl =  $('input[name=commitId]');
                    if (selectENV.attr('data-type') !== 'undefined') {
                        var type = selectENV.attr('data-type');
                        data[type] = (type === 'redeploy')? commitIdEl.val() : selectENV.attr('data-' + type);
                    }
                    if (selectENV.attr('data-site') !== 'undefined') {
                        data.site = selectENV.attr('data-site');
                    }
                    data.env = selectENV.val();
                    data.org = $('select[name=ORG]').val();
                    $.ajax({
                        url: url_run,
                        type: "POST",
                        data: data,
                        cache: false,
                        beforeSend: function () {
                            if (!git_cmd_running) {
                                $results.parent().fadeOut();
                                $results.parent().before(temp_load);
                            }
                            $('html').addClass('wait');
                            git_cmd_running = true;
                        },
                        success: function (data) {
                            if (git_cmd_running2) return;
                            var jsonResult = parseDeployResult(data);
                            if (jsonResult.status == "done") {
                                if ($.trim(data)==""){
                                  jsonResult.data = getFirstLogDetail();
                                }
                                checkError(jsonResult.data);
                                $results.html(jsonResult.data);
                                $results.parent().fadeIn();
                                changeTitle("Deploy Successfully < [Global] SFCC.DEPLOY");
                                push('[Global] SFCC.DEPLOY','Deployed successfully, please check! \n\n' + jsonResult.data);
                                git_cmd_running = false;
                                $("#temp_load").remove();
                                $('html').removeClass('wait');
                                //$('select[name=ENV] option').eq(0).prop('selected', true);
                                playAudio("success");
                                playAudio("go-cua");
                                parseDeployQueueResult(jsonResult.deployQueue);
                                getLogs();
                                if (jsonResult.deployQueue.hasInProgress === true) {
                                    setTimeout(function(){
                                        getDeployResult();
                                    }, 1000);
                                }
                            } else {
                                getDeployResult();
                            }
                        },
                        error: function (xhr, status, errorThrown) {
                            //Here the status code can be retrieved like;
                            //xhr.status;
                            //The message added to Response object in Controller can be retrieved as following.
                            //xhr.responseText;
                            getDeployResult();
                        },
                    });
                });

                function getDeployResult() {
                    var deployResultInterval = setInterval(function () {
                        var url_run = url_root + "/deploy-" + Date.now() + ".php";
                        $.ajax({
                            url: url_run,
                            type: "GET",
                            cache: false,
                            beforeSend: function () {
                                if ($("#temp_load").length === 0) {
                                    $results.parent().fadeOut();
                                    $results.parent().before(temp_load);
                                    $('html').addClass('wait');
                                }
                            },
                            success: function (data) {
                                var jsonResult = parseDeployResult(data);
                                parseDeployQueueResult(jsonResult.deployQueue);
                                if (jsonResult.status == "done") {
                                    if ($.trim(data)==""){
                                      jsonResult.data = getFirstLogDetail();
                                    }
                                    checkError(jsonResult.data);
                                    $results.html(jsonResult.data);
                                    $results.parent().fadeIn();
                                    changeTitle("Deploy Successfully < [Global] SFCC.DEPLOY");
                                    push('[Global] SFCC.DEPLOY','Deployed successfully, please check! \n\n' + jsonResult.data);
                                    git_cmd_running = false;
                                    $("#temp_load").remove();
                                    $('html').removeClass('wait');
                                    //$('select[name=ENV] option').eq(0).prop('selected', true);
                                    playAudio("success");
                                    playAudio("go-cua");
                                    getLogs();
                                    clearInterval(deployResultInterval);
                                    if (jsonResult.deployQueue.hasInProgress === true) {
                                        setTimeout(function(){
                                            getDeployResult();
                                        }, 1000);
                                    }
                                    return;
                                }
                                if (jsonResult.status == "deploying") {
                                    $results.html(jsonResult.data);
                                    $results.parent().fadeIn();
                                    $('html, body').animate({
                                        scrollTop: $results.parent().offset().top + $results.parent().height()
                                    }, 350);
                                    return;
                                }
                                git_cmd_running = false;
                                $("#temp_load").remove();
                                clearInterval(deployResultInterval);
                            },
                        });
                    }, 3000);
                }

                function getLogs() {
                    var url_run = url_root + "/log.php";
                    var logLists = $('#log-list');
                    $.ajax({
                        url: url_run,
                        type: "GET",
                        cache: false,
                        data: { action: 'list' },
                        beforeSend: function () {
                            $('html').addClass('wait');
                        },
                        success: function (data) {
                            logLists.html(data);
                            $('input[name=commitId]').hide();
                            $('html').removeClass('wait');
                        },
                    });
                }

                function parseDeployQueueResult(data) {
                    if (data.total === -1) return;
                    $('#deploy_queue_list_ul').html(data.html);
                    $('#deploy_queue_list_cnt').html(data.total);
                    if (data.total > 0) {
                        $('#deploy_queue_list').fadeIn(350);
                        if (!$('#deploy_queue_list_collapse').hasClass('in')) $('#deploy_queue_list_collapse_a').trigger('click');
                    } else {
//                         $('#deploy_queue_list').fadeOut(350);
                    }
                }

                function getLogDetail(file) {
                    getLogs();
                    var url_run = url_root + "/log.php";
                    $.ajax({
                        url: url_run,
                        type: "GET",
                        cache: false,
                        data: { action: 'detail', file: file },
                        beforeSend: function () {
                            $('html').addClass('wait');
                        },
                        success: function (data) {
                            $results.html(data);
                            $results.parent().fadeIn();
                            $('#panel-logs .panel-title a').trigger('click');
                            $('html').removeClass('wait');
                        },
                    });
                }

                function getFirstLogDetail() {
                    var url_run = url_root + "/log.php";
                    var logLists = $('#log-list');
                    var returnData;
                    $.ajax({
                        url: url_run,
                        type: "GET",
                        cache: false,
                        data: { action: 'detail', file: logLists.find('li:first').find('a').attr('data-file') },
                        beforeSend: function () {
                            $('html').addClass('wait');
                        },
                        success: function (data) {
                            returnData = data;
                            $('html').removeClass('wait');
                        },
                    });
                    return returnData;
                }
                
               
                function checkError(content){
                    if (typeof content === 'undefined') return false;
                    if (content.indexOf('ERROR&nbsp;in') !== -1 || content.indexOf('needs merge') !== -1 || content.indexOf('CONFLICT') !== -1 || content.indexOf('Successfully uploaded') === -1){
                        $('#imgDeployFailed').show();
                        alert('Deploy Failed!!!');
                        return true;
                    }
                    $('#imgDeployFailed').hide();
                    return false;
                }
                
                <?php 
                if (file_exists($deployPath) || file_exists($deployRunningPath)) :
                ?>
                    if ($("#temp_load").length === 0) {
                        $results.parent().fadeOut();
                        $results.parent().before(temp_load);
                    }
                    getDeployResult();
                <?php 
                endif;
                ?>
                

                $(document).on("click touchend", "#log-list .list-group-item a", function (e) {
                    e.preventDefault();
                    var file = $(this).attr('data-file');
                    getLogDetail(file);
                });

                $(document).on("click touchend", "#panel-logs .panel-heading, #panel-logs .panel-footer", function (e) {
                    e.preventDefault();
                    $('#panel_log_collapse_a').trigger('click');
                });

                $(document).on("click touchend", "#deploy_queue_list .panel-heading", function (e) {
                    e.preventDefault();
                    $('#deploy_queue_list_collapse_a').trigger('click');
                });

                $(document).on("change", "select[name=ENV]", function () {
                    var selectENV =  $('select[name=ENV] option:selected');
                    var commitIdEl =  $('input[name=commitId]');
                    if (selectENV.attr('data-type') === 'redeploy') {
                        commitIdEl.fadeIn(350);
                    } else {
                        commitIdEl.hide();
                    }
                });

                // Enable pusher logging - don't include this in production
                Pusher.logToConsole = false;

                var pusher = new Pusher('0accc99449e317f329c6', {
                    cluster: 'ap1',
                    forceTLS: true
                });

                var channel = pusher.subscribe('vho-deploy-channel');
                channel.bind('vho-deploy-event', function (data) {
                    var jsonData = JSON.stringify(data);
                    if (data.hasInProgress == 1) {
                        getDeployResult();
                    }
                });

                var audio_list = ["quaqua", "soi-hu", "dan-cho-sua", "ga-cuc-tac", "tieng-de-keu"];
                var audio_name = audio_list[Math.floor(Math.random() * audio_list.length)];

                setTimeout(function () {
                    playAudio(audio_name);
                }, 3000);
                var interval_quaqua = setInterval(function () {
                    playAudio(audio_name);
                    setTimeout(function () {
                        stopAudio(audio_name);
                    }, 12000);
                }, 20000);
            });
        </script>
        <a href="#" rel="nofollow" class="scrollToTop button"><i class="scrollTo-icon angle-up" style="margin:0"></i></a>
        <a href="#" rel="nofollow" class="scrollToBottom button"><i class="scrollTo-icon angle-down" style="margin:0"></i></a>
    </body>
</html>
