<?php
require_once 'config.php';

function get_csrf()
{
    // Create a new CSRF token.
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = base64_encode(openssl_random_pseudo_bytes(32));
    }
}

function format_result($data)
{
    $data = str_replace("<<", "<b>", $data);
    $data = str_replace(">>", "</b>", $data);
    $data = str_replace("Warning: Using a password on the command line interface can be insecure", "Done", $data);
    //$data = str_replace("+","<span style='color:#07DB00;'>+</span>",$data);
    //$data = str_replace("-","<span style='color:#BA0000;'>-</span>",$data);
    $data = preg_replace("@no such target: ([a-zA-Z0-9\-\_]+) Successfully@", "Successfully", $data);
    $data = preg_replace("@> vinfast-na-storefronts\@1.0.0 upload:all /system/SOURCE.SFCC > node lib/cartridge uploadAll (.*) Successfully@", "Successfully", $data);
    $data = preg_replace("@On branch (.*)\n@", "On branch <strong style='color:#003996;'>$1</strong>\n", $data);
    $data = preg_replace("@Deleting file (.*).\n@", "<span style='color:#aaaaaa;'>Deleting file $1.</span>\n", $data);
    $data = preg_replace("@\{ \'file\-upload\'\: false,(.*)\'file\-delete\'\: false \}@", "", $data);
    $data = preg_replace("@\{&nbsp;\'file\-upload\'\:&nbsp;false,(.*)\'file\-delete\'\:&nbsp;false&nbsp;\}@", "", $data);

    $data = preg_replace('/##(.*?)HEAD/', '', $data);
    $data = preg_replace('/' . PHP_EOL . '/', '<br>', $data);
    $data = preg_replace('/ /', '&nbsp;', $data);

    $data = str_replace('[1m[37m', '<span class="color-white">', $data);
    $data = str_replace('[1m[36m', '<span class="color-cyan">', $data);
    $data = str_replace('[1m[35m', '<span class="color-magenta">', $data);
    $data = str_replace('[1m[34m', '<span class="color-blue">', $data);
    $data = str_replace('[1m[33m', '<span class="color-yellow">', $data);
    $data = str_replace('[1m[32m', '<span class="color-green">', $data);
    $data = str_replace('[1m[31m', '<span class="color-red">', $data);
    $data = str_replace('[1m[30m', '<span class="color-black">', $data);
    $data = str_replace('[1m', '<span class="color-orange">', $data);

    $data = str_replace('[39m[22m', '</span>', $data);

    $data = preg_replace('/\[1;30m/', '<span class="color-black">', $data);
    $data = preg_replace('/\[1;31m/', '<span class="color-red">', $data);
    $data = preg_replace('/\[1;32m/', '<span class="color-green">', $data);
    $data = preg_replace('/\[1;33m/', '<span class="color-yellow">', $data);
    $data = preg_replace('/\[1;34m/', '<span class="color-blue">', $data);
    $data = preg_replace('/\[1;35m/', '<span class="color-magenta">', $data);
    $data = preg_replace('/\[1;36m/', '<span class="color-cyan">', $data);
    $data = preg_replace('/\[1;37m/', '<span class="color-white">', $data);
    $data = preg_replace('/\[37m/', '<span class="color-white">', $data);
    $data = preg_replace('/\[36m/', '<span class="color-cyan">', $data);
    $data = preg_replace('/\[35m/', '<span class="color-magenta">', $data);
    $data = preg_replace('/\[34m/', '<span class="color-blue">', $data);
    $data = preg_replace('/\[33m/', '<span class="color-yellow">', $data);
    $data = preg_replace('/\[32m/', '<span class="color-green">', $data);
    $data = preg_replace('/\[31m/', '<span class="color-red">', $data);
    $data = preg_replace('/\[30m/', '<span class="color-black">', $data);

    $data = preg_replace('/\[39m/', '</span>', $data);
    $data = preg_replace('/\[m/', '</span>', $data);
    $data = preg_replace('/\[0m/', '</span>', $data);
    $data = preg_replace('//', '', $data);

    $data = preg_replace('/Successfully&nbsp;uploaded/', '<span class="color-magenta">Successfully uploaded</span>', $data);
    $data = preg_replace('/Successfully&nbsp;deleted/', '<span class="color-red">Successfully deleted</span>', $data);
    $data = preg_replace('/<br>no&nbsp;such&nbsp;target:&nbsp;([a-zA-Z0-9\-\_]+)<br>/', '', $data);
    $data = preg_replace('/>&nbsp;vinfast-na-storefronts\@1\.0\.0&nbsp;upload\:all&nbsp;\/system\/SOURCE\.SFCC<br>/', '', $data);
    $data = preg_replace('/>&nbsp;node&nbsp;lib\/cartridge&nbsp;uploadAll&nbsp;"([a-zA-Z0-9\-\_]+)"<br>/', '', $data);

    return $data;
}

function human_filesize($size, $precision = 2)
{
    $space = ' ';
    $units = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
    $step = 1024;
    $i = 0;
    while (($size / $step) > 0.9) {
        $size = $size / $step;
        $i++;
    }
    return round($size, $precision) . $space . $units[$i];
}

function getFileExtension($file_name)
{
    return preg_replace('/^.*\.([^.]+)$/D', '$1', $file_name);;
}

function get_deploy_queue_list($sz = 30, $offset = 0, $onlyCurrentDate = false)
{
    $list = [];
    $files = scan_dir(QUEUE_PATH);
    $total = count($files);
    $offset = ($offset < $total) ? $offset : 0;
    $sz = $sz + $offset;
    if (!$files) return [];
    for ($i = $offset; $i < $sz && $i < $total; $i++) {
        $filePath = QUEUE_PATH . '/' . $files[$i];
        if ($onlyCurrentDate && date("Y/m/d", filemtime($filePath)) !== date("Y/m/d")) continue;
        $fileExt = getFileExtension($filePath);
        $status = ($fileExt !== 'cmd') ? $fileExt : 'waiting';
        $fileName = preg_replace('/(.done|.cmd|.inprogress|.waiting)/', '', $files[$i]);
        $list[] = array('name' => $fileName, 'status' => $status, 'lastModified' => date("Y/m/d H:i:s", filemtime($filePath)));
    }
    return $list;
}

function get_log_list($sz = 15, $offset = 0)
{
    $files = scan_dir(LOG_PATH);
    $total = count($files);
    $offset = ($offset < $total) ? $offset : 0;
    $sz = $sz + $offset;
    if (!$files) return [];
    for ($i = $offset; $i < $sz && $i < $total; $i++) {
        $filePath = LOG_PATH . '/' . $files[$i];
        $list[] = array('name' => $files[$i], 'size' => human_filesize(filesize($filePath)));
    }
    return $list;
}

function scan_dir($dir, $arsort = true)
{
    $ignored = array('.', '..', '.svn', '.htaccess');

    $files = array();
    foreach (scandir($dir) as $file) {
        if (in_array($file, $ignored)) continue;
        if (is_file($dir . '/' . $file)) $files[$file] = filemtime($dir . '/' . $file);
    }
    if ($arsort) arsort($files);
    $files = array_keys($files);

    return ($files) ? $files : [];
}

function get_conf($env)
{
    $file = CONF_PATH . "/" . strtolower($env) . ".json";
    if ($file === '') return [];
    if ($file && file_exists($file)) {
        $confRaw = file_get_contents($file);
        $confJson = json_decode($confRaw, true);
        return $confJson;
    }
    return [];
}

/**
 * @param string $env
 * @param array $data
 */
function set_conf($env, $data)
{
    $file = CONF_PATH . "/" . strtolower($env) . ".json";
    if ($file === '') return false;
    if (!file_exists($file)) {
        $myfile = fopen($file, "w") or die("Unable to open file!");
        fclose($myfile);
    }
    $confJson = get_conf($env);
    $confJson = array_merge($confJson, $data);
    file_put_contents($file, json_encode($confJson, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
}


function handlerException($severity, $message, $file, $line)
{
    throw new ErrorException($message, $severity, $severity, $file, $line);
}

function handlerExceptionMessage($e)
{
    return "Exception happen:\nFile {" . $e->getFile() . "}\tLine {" . $e->getLine() . "}\nError message is {" . $e->getMessage() . "} \nTrace:\n" . $e->getTraceAsString() . "";
}

function saveLog($request_data, $logName = null)
{
    $logFilePath = ERROR_LOGS_PATH . "/". date('Ymd') .".txt";
    if (!file_exists($logFilePath)) {
        $myfile = fopen($logFilePath, "w") or die("Unable to open file!");
        fwrite($myfile, '');
        fclose($myfile);
    }
    file_put_contents($logFilePath, '-----------------------------------------' . PHP_EOL . '########## ' . date('Y-m-d H:i:s') . ' ########## => ' . (!empty($logName) ? $logName . ' => ' : '') . PHP_EOL . '-----------------------------------------' . PHP_EOL . ((!empty($request_data)) ? (is_array($request_data) ? json_encode($request_data) : $request_data) . PHP_EOL . '-----------------------------------------' : '') . PHP_EOL . PHP_EOL, FILE_APPEND | LOCK_EX);
}

class JSON
{
    static function encode($data)
    {
        if (is_array($data)) return json_encode($data, JSON_UNESCAPED_UNICODE);
        else return $data;
    }

    static function decode($data)
    {
        if (is_string($data)) return json_decode($data, true, 512, JSON_BIGINT_AS_STRING);
        else return $data;
    }

    static function parseFile($path)
    {
        $jsonStr = file_get_contents($path);
        return JSON::decode($jsonStr);
    }
}

function curlGET($url)
{
    $header = array('Accept: application/json', 'Content-Type: application/json');
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}

function prepareHeaders($headers)
{
    $flattened = array();
    foreach ($headers as $key => $header) {
        if (is_int($key)) {
            $flattened[] = $header;
        } else {
            $flattened[] = $key . ': ' . $header;
        }
    }
    return implode("\r\n", $flattened) . "\r\n";
}

function curlPOST($url, $data)
{
    $postdata = json_encode($data);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

class TelegramHelper
{
    private static $BOT_TOKEN;
    private static $CHAT_ID;

    static function init()
    {
        self::$BOT_TOKEN = '1913828310:AAF330-zpGwNGMyaPkfam9f69ZvirvhOwvc';
        self::$CHAT_ID = '-1001571858217';
        // How to get chat_id? call api getUpdates -> Use this method to receive incoming updates using long polling.
        // call api: https://api.telegram.org/bot$BOT_TOKEN/getUpdates
    }

    static function sendMessage($message, $reply_to_message_id = null)
    {
        try {
            $botToken = self::$BOT_TOKEN;
            $data = [
                'chat_id' => self::$CHAT_ID,
                'text' => $message
            ];
            if (!empty($reply_to_message_id)) $data['reply_to_message_id'] = $reply_to_message_id;
            return curlGET("https://api.telegram.org/bot$botToken/sendMessage?" . http_build_query($data));
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper sendMessage Exception');
        }
    }

    static function deleteMessage($message_id)
    {
        try {
            $botToken = self::$BOT_TOKEN;
            $data = [
                'chat_id' => self::$CHAT_ID,
                'message_id' => $message_id
            ];
            return curlGET("https://api.telegram.org/bot$botToken/deleteMessage?" . http_build_query($data));
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper deleteMessage Exception');
        }
    }

    static function createFile($message, $message_id = null, $merge_request_id = null)
    {
        try {
            $fileContent = "cd \"" . ROOT_PATH . "\"" . PHP_EOL;
            $data = ['merge_request_id' => $merge_request_id];

            if (empty($message) && !empty($message_id)) { //deleteMessage
                $data['message_id'] = $message_id;
                $fileContent .= "curl \"http://deploy.sfcc.eu.org/telegram.php?act=deleteMessage&" . http_build_query($data) . "\"" . PHP_EOL;
            } else { //sendMessage
                //$message = str_replace('vhgl.southeastasia.cloudapp.azure.com', 'vhgl.247demo.xyz', $message);
                $data['message'] = $message;
                if (!empty($message_id)) $data['reply_to_message_id'] = $message_id;
                $fileContent .= "curl \"http://deploy.sfcc.eu.org/telegram.php?act=sendMessage&" . http_build_query($data) . "\"" . PHP_EOL;
            }

            createBashFile('telegram', $fileContent);
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper createFile Exception');
        }
    }

    static function getRequestId($merge_request_id)
    {
        $filePath = NOTIFY_PATH . "/merge_request.json";
        if (!file_exists($filePath)) return null;
        try {
            $confRaw = file_get_contents($filePath);
            $confJson = JSON::decode($confRaw);
            return isset($confJson[$merge_request_id])? $confJson[$merge_request_id] : null;
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper getMessageId Exception');
        }
        return null;
    }

    static function saveRequestId($merge_request_id, $message_id)
    {
        $filePath = NOTIFY_PATH . "/merge_request.json";
        try {
            $confRaw = file_get_contents($filePath);
            $confJson = JSON::decode($confRaw);
            $confJson[$merge_request_id] = $message_id;
            file_put_contents($filePath, JSON::encode($confJson));
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper saveMessageId Exception');
        }
    }

    static function deleteRequestId($merge_request_id)
    {
        $filePath = NOTIFY_PATH . "/merge_request.json";
        try {
            $confRaw = file_get_contents($filePath);
            $confJson = JSON::decode($confRaw);
            if (isset($confJson[$merge_request_id])) {
                unset($confJson[$merge_request_id]);
            }
            file_put_contents($filePath, JSON::encode($confJson));
        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TelegramHelper deleteRequestId Exception');
        }
    }

}

TelegramHelper::init();

class TeamsIncomingWebhookHelper
{
    private static $IncomingWebhookURL;

    static function init()
    {
        self::$IncomingWebhookURL = 'https://vingroupjsc.webhook.office.com/webhookb2/9378398d-bf6d-4e1e-83da-39101eadd1eb@ed6a2939-d153-4f92-94f8-3d790d96c9f8/IncomingWebhook/c98241ec88844526b76000376c3ba1b3/d5ea8d7e-807d-49dc-a802-f4e4dc5783e4';
    }

    static function sendMessage($message)
    {
        try {
            $IncomingWebhookURL = self::$IncomingWebhookURL;

            createBashFile('teams', "curl -H 'Content-Type: application/json' -d '{\"text\": \"$message\"}' $IncomingWebhookURL");

        } catch (Exception $e) {
            saveLog(handlerExceptionMessage($e), 'TeamsIncomingWebhookHelper sendMessage Exception');
        }
    }

}

TeamsIncomingWebhookHelper::init();

function createBashFile($type, $content)
{
    $bashContent = '#!/bin/bash' . PHP_EOL;
    $bashContent .= $content . PHP_EOL;
    $dateTime = date('YmdHis').rand();
    $filePath = NOTIFY_PATH . "/$dateTime.$type.cmd";
    file_put_contents($filePath, $bashContent);
}



function isCompileError($deployResult) {
    $isError = false;
    $errors = [];
    
    $re = '/CONFLICT \(content\)/m';
    preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
    if ($matches && count($matches) && count($matches[0])) $errors[] = 'There are "CONFLICT" not resolved';

    $re = '/Automatic merge failed;/m';
    preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
    if ($matches && count($matches) && count($matches[0])) $errors[] = 'Automatic merge failed';
    
    $re = '/ERROR in .\/cartridges\//m';
    preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
    if ($matches && count($matches) && count($matches[0])) $errors[] = 'Compile failed';
    
    $re = '/ModuleBuildError/m';
    preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
    if ($matches && count($matches) && count($matches[0])) $errors[] = 'Compile failed';
    
    if (count($errors)) $errors = array_values(array_unique($errors));
    
    $isError = (count($errors) > 0);
    
    return $isError ? $errors : false;
}