<?php
require_once 'function.php';
require_once 'class.GoogleAuthenticator.php';
$ga = new PHPGangsta_GoogleAuthenticator();

$user = isset($_REQUEST['user']) ? $_REQUEST['user'] : null;
if (empty($user)) {
    die('please enter username');
}

if (!file_exists(twoFAConfigPath)) file_put_contents(twoFAConfigPath, '{}');
$confRaw = file_get_contents(twoFAConfigPath);
$confJson = JSON::decode($confRaw);

$secret = isset($confJson[$user]) ? $confJson[$user] : null;
if (empty($secret)) {
    $secret = $ga->createSecret();
    $confJson[$user] = $secret;
    $confRaw = JSON::encode($confJson);
    file_put_contents(twoFAConfigPath, $confRaw);
}

$oneCode = isset($_POST['code']) ? $_POST['code'] : null;
if (isset($_POST) && !empty($oneCode)) {
    header('Content-Type: application/json; charset=utf-8');
    $result = array('status' => 'error', 'msg' => '');
    $verifyCode = $ga->verifyCode($secret, $oneCode, 8);
    if ($verifyCode) {
        $result['status'] = 'success';
    }
    $result['verifyCode'] = $verifyCode;
    echo json_encode($result);
    exit();
}

$site = 'console.sfcc';
$qrCodeUrl = $ga->getQRCodeGoogleUrl("$user@$site", $secret);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>🚀 2FA * Google Authenticator</title>
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <style>
        body{
            padding: 50px;
        }
        .app {
            height: 35px;
        }
    </style>
</head>
<body>
<div style="text-align:center">
<?php echo '<img src="'.$qrCodeUrl.'" />'; ?>
</div>

<div style="text-align:center">
    <h3>Get Google Authenticator on your phone</h3>
    <a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8" target="_blank"><img class="app" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Download_on_the_App_Store_Badge.svg/135px-Download_on_the_App_Store_Badge.svg.png" /></a>
    <a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en" target="_blank"><img class="app" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Google_Play_Store_badge_EN.svg/120px-Google_Play_Store_badge_EN.svg.png" /></a>
</div>
</body>
</html>