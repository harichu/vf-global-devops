<?php require_once 'function.php';

$act = isset($_REQUEST['act'])? $_REQUEST['act'] : '';
$merge_request_id = isset($_REQUEST['merge_request_id'])? $_REQUEST['merge_request_id'] : '';
$file = isset($_REQUEST['file'])? strtolower($_REQUEST['file']) : '';


if ($act === 'success' && $file) {
    file_put_contents("logs.txt", json_encode($_REQUEST) . PHP_EOL, FILE_APPEND | LOCK_EX);
    $filePath = LOG_PATH . '/' . $file . '.txt';
    if (file_exists($filePath)) {
        $deployResult = file_get_contents($filePath);
        
        $re = '/\[1;32m> git branch: \[0m\[\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m\]/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $gitBranch = $matches[0][1] ?? '';
        
        $re = '/\[1;32m> code version: \[0m\[\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m\]/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $codeVersion = $matches[0][1] ?? '';
        
        $re = '/\[1;32m> sandbox: \[0m\[1;33m([a-zA-Z0-9\/\-\_\.]+)\[0m/m';
        preg_match_all($re, $deployResult, $matches, PREG_SET_ORDER, 0);
        
        $sandbox = $matches[0][1] ?? '';
         
        if ($gitBranch && $codeVersion && $sandbox) {
            $sandbox = str_replace('sandbox.us01.', '', $sandbox);
            $sandbox = str_replace('cert.staging.eu01.vinfast.demandware.net', 'staging-eu01-vinfast.demandware.net/s/VinfastEU/fr_FR/reservation/', $sandbox);
            $sandbox = str_replace('cert.staging.na01.vinfast.demandware.net', 'staging-na01-vinfast.demandware.net/s/Vinfast-US/en/reservation; staging-na01-vinfast.demandware.net/s/Vinfast-CA/reservation/?lang=en_CA', $sandbox);
            $sandbox = str_replace('development-eu01-vinfast.demandware.net', 'uat-rh.vinfastauto.eu', $sandbox);
            $sandbox = str_replace('development-na01-vinfast.demandware.net', 'uatshop01.vinloyalty.com; uatshop01.vinfastauto.ca', $sandbox);
            
            $messageTitle = (isCompileError($deployResult) !== false && count(isCompileError($deployResult)) > 0)? "🚀 ❌ Deploy ERROR 💥" . implode(PHP_EOL . PHP_EOL, isCompileError($deployResult)) : "🚀 ✅ Deploy successfully ✅";
            
            $message = $messageTitle . PHP_EOL . PHP_EOL .  "> git branch: $gitBranch" . PHP_EOL . PHP_EOL .  "> code version: $codeVersion" . PHP_EOL . PHP_EOL .  "> sandbox: $sandbox";
            echo $message;
            $reply_to_message_id = isset($_REQUEST['reply_to_message_id'])? $_REQUEST['reply_to_message_id'] : '';
            
            if ($reply_to_message_id) {
                $reply_to_message_id_saved = TelegramHelper::getRequestId($reply_to_message_id);
                if ($reply_to_message_id_saved) $reply_to_message_id = $reply_to_message_id_saved;
            }
            
            $sendMessageResult = TelegramHelper::sendMessage(preg_replace('/> /','👉 ',$message), $reply_to_message_id);
            //TelegramHelper::deleteMessage($reply_to_message_id);
            TeamsIncomingWebhookHelper::sendMessage($message);
        }
    }
    exit;
}


if ($act === 'sendMessage') {
    $message = isset($_REQUEST['message'])? $_REQUEST['message'] : '';
    $reply_to_message_id = isset($_REQUEST['reply_to_message_id'])? $_REQUEST['reply_to_message_id'] : '';
    $sendMessageResult = TelegramHelper::sendMessage($message, $reply_to_message_id);
    if (!empty($sendMessageResult)) {
        $sendMessageResultJson = JSON::decode($sendMessageResult);
        if ($sendMessageResultJson['ok'] === true) {
            $messageResult = $sendMessageResultJson['result'];
            $result_message_id = $messageResult['message_id'];
            TelegramHelper::saveRequestId($merge_request_id, $result_message_id);
        }
    }
    exit;
}

if ($act === 'deleteMessage') {
    $message_id = isset($_REQUEST['message_id'])? $_REQUEST['message_id'] : '';
    TelegramHelper::deleteMessage($message_id);
    TelegramHelper::deleteRequestId($merge_request_id);
    exit;
}
