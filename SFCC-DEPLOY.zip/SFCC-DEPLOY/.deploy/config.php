<?php
define('ENVIRONMENT', 'development');

if (ENVIRONMENT == 'development' || ENVIRONMENT == 'dev') {
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
} else {
    error_reporting(0);
    ini_set("display_errors", 0);
}

date_default_timezone_set('Asia/Ho_Chi_Minh');

//ini_set('session.save_path', realpath('/tmp/php-session'));
if (!isset($_SESSION) || session_status() == PHP_SESSION_NONE) {
	session_start();
}

define('ROOT_PATH', '/system/SFCC-DEPLOY/.deploy');
define('CONF_PATH', '/system/SFCC-DEPLOY/CONF');
define('CMD_PATH', ROOT_PATH. '/.cmd');
define('TMP_PATH', ROOT_PATH. '/.tmp');
define('LOG_PATH', ROOT_PATH. '/.log');
define('ERROR_LOGS_PATH', ROOT_PATH. '/.error_logs');
define('QUEUE_PATH', ROOT_PATH. '/.queue');
define('NOTIFY_PATH', ROOT_PATH. '/.notifications');

$deployPath = CMD_PATH. "/deploy.cmd"; define('deployPath', $deployPath);
$deployRunningPath = TMP_PATH. "/deploy.run"; define('deployRunningPath', $deployRunningPath);
$deployDonePath = TMP_PATH. "/deploy.done"; define('deployDonePath', $deployDonePath);
$deployResultPath = TMP_PATH. "/deploy.result"; define('deployResultPath', $deployResultPath);

define('guiConfigPath', CONF_PATH. "/GUI.json");
define('uatConfigPath', CONF_PATH. "/uat.json");
define('stgConfigPath', CONF_PATH. "/stg.json");
define('twoFAConfigPath', CONF_PATH. "/2FA.json");
$uatConfigPath = uatConfigPath;
$stgConfigPath = stgConfigPath;
