<?php require_once 'function.php';
TeamsIncomingWebhookHelper::sendMessage('ping');
