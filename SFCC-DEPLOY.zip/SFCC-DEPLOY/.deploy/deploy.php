<?php require_once 'function.php'; require_once 'auth.php';

$action = (isset($_POST['action']))? $_POST['action'] : '';
if ($action === 'deploy_queue_list') {
    die(json_encode(deploy_queue_list()));
}

function deploy_queue_list(){
    $deploy_queue_list = get_deploy_queue_list(999, 0, true);
    $queue_list_html = '';
    $hasInProgress = false;
    if (count($deploy_queue_list)) {
        foreach($deploy_queue_list as $file){
            if ($file['status'] === 'waiting') $hasInProgress = true;
            $statusIcon = (($file['status'] === 'done')? '' : (($file['status'] === 'inprogress')? '<i class="fa fa-spinner fa-spin" aria-hidden="true"></i> ' : '<i class="fa fa-hourglass-half" aria-hidden="true"></i> '));
            $queue_list_html .= '<li class="list-group-item">'. $file['name'] .'<span class="badge badge-pill '.(($file['status'] === 'done')? 'bg-success' : (($file['status'] === 'inprogress')? 'bg-danger':'bg-secondary')).'">'. $statusIcon .''. $file['status'] .'</span></li>';
        }
    }
    $resultJson = array(
        'total' => count($deploy_queue_list),
        'hasInProgress' => $hasInProgress,
        'html' => $queue_list_html
    );
    return $resultJson;
}

$org = (isset($_POST['org']))? $_POST['org'] : '';
$orgs = (!is_array($org) && $org)? [$org] : $org;

if (!empty($_POST)  && (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) && $orgs && count($orgs) > 0){
    foreach($orgs as $org){
        $env = (isset($_POST['env']))? $_POST['env'] : 'UAT';
        $mode = (isset($_POST['mode']))? $_POST['mode'] : 'Changed';
        $cartridges = (explode(":", $env))[1] ?? null;
        $env = (explode(":", $env))[0] ?? $env;
        $env = $org . '-' . $env;
        $deployPath = str_replace('deploy.cmd', 'deploy.'.$env.'.cmd', deployPath);
        if ($mode === 'Cartridges') $cartridges = true;
        if ($mode === 'CartridgesXML') $cartridgesXML = true;
        
        if (!file_exists($deployPath)){
			if ($cartridges) $env .= ' --cartridges 1';
			else if ($cartridgesXML) $env .= ' --cartridges 2';
            $myfile = fopen($deployPath, "w") or die("Unable to open file!");
            fwrite($myfile, $env);
            fclose($myfile);
        }
    }
}

for($i = 0; $i < 1; $i++){
    sleep(1);
    if (file_exists($deployDonePath)){
        // sleep(3);
        $resultPath = file_get_contents($deployDonePath);
        $deployResult = file_get_contents(trim($resultPath));
        $deployResult = "<pre>" . format_result($deployResult) . "</pre>" ;
        $deploy_queue_list = deploy_queue_list();
        unlink($deployDonePath);
        if (file_exists($deployRunningPath)) unlink($deployRunningPath);
        $resultJson = array('status' => ($deploy_queue_list['total'] > 0)? 'deploying':'done', 'data' => $deployResult, 'deployQueue' => $deploy_queue_list);
        die(json_encode($resultJson));
    }
}

if (file_exists($deployRunningPath)) {
    $deployResult = file_get_contents($deployResultPath);
    $deployResult = "<pre>" . format_result($deployResult) . "</pre>" ;
    $resultJson = array('status' => 'deploying', 'data' => $deployResult, 'deployQueue' => deploy_queue_list());
    die(json_encode($resultJson));
}