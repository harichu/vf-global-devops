<?php require_once 'function.php'; require_once 'auth.php';
    if (@$currentUser !== 'stg' && @$currentUser !== 'prod') { header('location: ./'); exit(); }
    if (empty($_POST)) { get_csrf(); }

    $ENVS = null;
    foreach (glob(CONF_PATH . "/*.json") as $filepath) {
        $filename = str_replace(CONF_PATH . "/", "", $filepath);
        if ($filename === 'GUI.json') continue;
        if ($filename === '2FA.json') continue;
        if (!is_writable($filepath)) continue;
        $ENVS[] = strtoupper(str_replace(".json", "", $filename));
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>🚀 ADMIN | VHO .UAT. DEPLOY</title>
        <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <link rel="stylesheet" href="./assets/css/bootstrap.min.css" media="screen" />
        <!-- <link rel="stylesheet" href="./assets/css/font-awesome.min.css" media="screen" />-->
        <link rel="stylesheet" href="./assets/css/styles.css?66666666" media="screen" />
        <link rel="shortcut icon" href="./assets/img/favicon.ico" />
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries https://cdn.dribbble.com/users/1431278/screenshots/3341394/trump_runner1.gif -->
        <!--[if lt IE 9]>
            <script src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
        html, body {
            overflow-x: hidden;
        }
        .jumbotron {
            position: relative;
        }
        .pager {
                position: absolute;
                width: 96%;
                left: 50%;
                top: 0;
                transform: translateX(-50%);
         }
         .pager .disabled>a, .pager .disabled>a:focus, .pager .disabled>a:hover, .pager .disabled>span {
                background-color: #89c2b6;
         }
         
        .col-lg-10.form-password-wraper {
            position: relative;
        }
         
         button.btn.btn-xs.btn-warning {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 25px;
        }
        </style>
    </head>
    <body>
    <?php
    $env = (isset($_REQUEST['env'])) ? $_REQUEST['env'] : 'NA-UAT';
    if(!empty($_POST) && $_SERVER['REQUEST_METHOD'] == 'POST' && (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token'])){
        $postData = [];
        if (isset($_POST['dw_hostname'])) $postData['dw_hostname'] = $_POST['dw_hostname'];
        if (isset($_POST['dw_username'])) $postData['dw_username'] = $_POST['dw_username'];
        if (isset($_POST['dw_password'])) $postData['dw_password'] = $_POST['dw_password'];
        if (isset($_POST['p12'])) $postData['p12'] = $_POST['p12'];
        if (isset($_POST['passphrase'])) $postData['passphrase'] = $_POST['passphrase'];
        if (isset($_POST['dw_version'])) $postData['dw_version'] = $_POST['dw_version'];
        if (isset($_POST['git_branch'])) $postData['git_branch'] = $_POST['git_branch'];
        if ( (isset($postData['dw_password']) && empty($postData['dw_password'])) || (isset($postData['passphrase']) && empty($postData['passphrase'])) ) {
            $errorMsg = "Trường <strong>password</strong> hoặc <strong>passphrase</strong> không được để trống";
        } else {
            set_conf($env, $postData);
            $_SESSION['csrf_token'] = base64_encode(openssl_random_pseudo_bytes(32));
            unset($_POST);
            $successMsg = "Cập nhật thành công";
        }
    }
    $confJson = get_conf($env);
    ?>
    <div class="container mt50">
        <div class="jumbotron row">
            <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">ENV
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
                <?php foreach ($ENVS as $ENV) :?>
                    <li class="next <?php echo ($env === $ENV)? 'disabled' : '';?>"><a href="?env=<?php echo $ENV;?>"><?php echo $ENV;?> config &rarr;</a></li>
                <?php endforeach; ?>
              </ul>
            </div>
            <form class="form-horizontal" action="" method="POST">
              <input type="hidden" name="env" value="<?php echo $env;?>">
              <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'];?>">
              <fieldset>
                <legend class="text-center">
                    <?php echo $env;?>.json
                </legend>
                <?php if (!empty(@$errorMsg)): ?>
                    <div class="alert alert-danger">
                        <?php echo $errorMsg;?>
                    </div>
                <?php endif; ?>
                <?php if (!empty(@$successMsg)): ?>
                    <div class="alert alert-info">
                        <?php echo $successMsg;?>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                  <label for="inputHostname" class="col-lg-2 control-label">hostname</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="inputHostname" name="dw_hostname" value="<?php echo @$confJson['dw_hostname'];?>" placeholder="dev05-ap01-vinhomes.demandware.net">
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputUsername" class="col-lg-2 control-label">username</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="inputUsername" name="dw_username" value="<?php echo @$confJson['dw_username'];?>" placeholder="v.haicv3@vinhomes.vn">
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputPassword" class="col-lg-2 control-label">password</label>
                  <div class="col-lg-10 form-password-wraper">
                    <button class="btn btn-xs btn-warning form-password-edit" type="button">Edit</button>
                    <input type="password" class="form-control form-password" id="inputPassword" name="dw_password" disabled readonly placeholder="*******">
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputP12" class="col-lg-2 control-label">p12</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="inputP12" name="p12" value="<?php echo @$confJson['p12'];?>" placeholder="path/to/file.p12">
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputPassphrase" class="col-lg-2 control-label">p12 passphrase</label>
                  <div class="col-lg-10 form-password-wraper">
                    <button class="btn btn-xs btn-warning form-password-edit" type="button">Edit</button>
                    <input type="password" class="form-control form-password" id="inputPassphrase" name="passphrase" disabled readonly placeholder="p12 passphrase">
                  </div>
                </div>

                <hr>
                
                <div class="form-group">
                  <label for="inputVersion" class="col-lg-2 control-label">Code Version</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="inputVersion" name="dw_version" value="<?php echo @$confJson['dw_version'];?>" placeholder="uat_20200620">
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputBranch" class="col-lg-2 control-label">Git deploy branch</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="inputBranch" name="git_branch" value="<?php echo @$confJson['git_branch'];?>" placeholder="uat_20200620">
                  </div>
                </div>
                
                <div class="form-group">
                  <div class="col-lg-10 col-lg-offset-2">
                    <a href="./" class="btn btn-default">  &larr; Back to home</a>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
              </fieldset>
            </form>
        </div>
    </div>
        <script src="./assets/js/jquery-1.12.4.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="./assets/push.js/push.min.js"></script>
        <!-- define the project's URL (to make AJAX calls possible, even when using this in sub-folders etc) -->
        <script>
            var url = "./";
        </script>
        <script src="./assets/js/setting.js?date=20200616"></script>

        <script>
            $(document).ready(function () {
                $(document).on('click', '.form-password-edit', function(e) {
                    e.preventDefault();
                    $(this).closest('.form-group').find('input[type=password]').prop('disabled', false);
                    $(this).closest('.form-group').find('input[type=password]').prop('readonly', false);
                });
            });
        </script>
    </body>
</html>
