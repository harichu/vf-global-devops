<?php
try {
    require __DIR__ . '/vendor/autoload.php';

    $options = array(
        'cluster' => 'ap1',
        'useTLS' => true
    );

    $pusher = new Pusher\Pusher(
        '0accc99449e317f329c6',
        'd324e5b5947de93a1536',
        '868326',
        $options
    );
} catch (Exception $e) {
    $pusher = null;
}

//$pusher->trigger('vho-deploy-channel', 'vho-deploy-event', $data);
//
