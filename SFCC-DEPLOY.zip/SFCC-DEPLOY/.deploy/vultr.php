<?php require_once 'function.php'; require_once 'auth.php'; require_once 'Vultr-API-PHP-class.php';

use Corbpie\VultrAPIv2\VultrAPI;
$vultr = new VultrAPI();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>🚀 [Global] SFCC.DEPLOY</title>
        <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <link rel="stylesheet" href="./assets/css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" href="./assets/css/font-awesome.min.css" media="screen" />
        <link rel="stylesheet" href="./assets/css/styles.css?999" media="screen" />
        <link rel="shortcut icon" href="./assets/img/favicon.ico" />
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries https://cdn.dribbble.com/users/1431278/screenshots/3341394/trump_runner1.gif -->
        <!--[if lt IE 9]>
            <script src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        
    
        <section class="vh-100" style="background-color: #eee;">
          <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
              <div class="col col-lg-9 col-xl-7">
                <div class="card rounded-3">
                  <div class="card-body p-4">
        
                    <table class="table mb-4">
                      <thead>
                        <tr>
                          <th scope="col">No.</th>
                          <th scope="col">Todo item</th>
                          <th scope="col">Status</th>
                          <th scope="col">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td>Buy groceries for next week</td>
                          <td>In progress</td>
                          <td>
                            <button type="submit" class="btn btn-danger">Delete</button>
                            <button type="submit" class="btn btn-success ms-1">Finished</button>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td>Renew car insurance</td>
                          <td>In progress</td>
                          <td>
                            <button type="submit" class="btn btn-danger">Delete</button>
                            <button type="submit" class="btn btn-success ms-1">Finished</button>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">3</th>
                          <td>Sign up for online course</td>
                          <td>In progress</td>
                          <td>
                            <button type="submit" class="btn btn-danger">Delete</button>
                            <button type="submit" class="btn btn-success ms-1">Finished</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
        
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        

        <div class="mainWrapper">
            <?php
            $listServers = json_decode($vultr->listServers(), true); //Data for all current account instances
            ?>
            <div class="container hover">
                <div class="panel-group">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                          listServers
                        </h4>
                      </div>
                      <div class="panel-collapse">
                        <ul class="list-group" id="log-list">
                        <?php foreach($listServers['instances'] as $server): ?>
                          <li class="list-group-item"><?php var_dump($server);?></li>
                        <?php endforeach; ?>
                        </ul>
                      </div>
                    </div>
                    <a data-toggle="collapse" id="panel_log_collapse_a" style="display:none" href="#collapse1"></a> 
                </div>
            </div>
            
        </div>

        <footer class="footer">
            <div class="container">
                <div class="row col-sm-12">
                    <p class="text-muted">Powered by © haicv3@SFDC.</p>
                </div>
            </div>
        </footer>
    </body>
</html>

