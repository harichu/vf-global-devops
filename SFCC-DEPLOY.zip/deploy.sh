#!/bin/bash

#install nvm if not installed
command -v nvm >/dev/null 2>&1 || { echo >&2 "nvm is required, but it's not installed.  installing....."; curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.31.2/install.sh | bash; }

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion


requireVersion=14.21
read currentVersion _ <<< $(nvm current)

checkVersion(){
# $1 = new version
# $2 = installed version
IFS='.' read -r -a nver <<< "$1"
IFS='.' read -r -a iver <<< "$2"
for ((i = 0 ; i < "${#nver[@]}" ; i++)) ;do
 case "$((${nver[i]}-${iver[i]}))" in
  -*) return 1 ;;
   0) ;;
   *) return 0 ;;
 esac
 false
done
}

isOldNodeVersion=`checkVersion "$currentVersion" "$requireVersion" && echo false || echo true`
if [ $isOldNodeVersion == 'true' ]; then
  installed=`nvm which $requireVersion | grep "not yet installed"`
  if [[ $installed != "" ]]; then
    nvm install $requireVersion
  fi
fi

function readJson {
  UNAMESTR=`uname`
  if [[ "$UNAMESTR" == 'Linux' ]]; then
    SED_EXTENDED='-r'
  elif [[ "$UNAMESTR" == 'Darwin' ]]; then
    SED_EXTENDED='-E'
  fi;

  VALUE=`grep -m 1 "\"${2}\"" ${1} | sed ${SED_EXTENDED} 's/^ *//;s/.*: *"//;s/",?//'`
  echo $VALUE ;
}

# ----------------------------------
# Colors
# ----------------------------------
NOCOLOR='\033[0m'
RED='\033[0;31m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHTGRAY='\033[0;37m'
DARKGRAY='\033[1;30m'
LIGHTRED='\033[1;31m'
LIGHTGREEN='\033[1;32m'
YELLOW='\033[1;33m'
LIGHTBLUE='\033[1;34m'
LIGHTPURPLE='\033[1;35m'
LIGHTCYAN='\033[1;36m'
WHITE='\033[1;37m'
# ----------------------------------

env=uat
conf=uat.json
force=0

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -e|--env) env="$2"; shift ;;
        -c|--conf) conf="$2"; shift ;;
        -f|--force) force="$2"; shift ;;
        -co|--compile) compile="$2"; shift ;;
        -ca|--cartridges) cartridges="$2"; shift ;;
        -s|--site) site="$2"; shift ;;
        -re|--redeploy) redeploy="$2"; shift ;;
        -tg|--telegramid) telegramid="$2"; shift ;;
        *) echo "Unknown parameter passed: $1";
    esac
    shift
done

env=`echo "${env^^}"`
env=`echo ${env//-VHO/}`
market=""

if [[ "$env" == "na-stg" || "$env" == "na-staging" || "$env" == "NA-STG" || "$env" == "NA-STAGING" ]]; then
    env=NA-STG
    conf=na-stg.json
    market="NA"
fi

if [[ "$env" == "na-uat" || "$env" == "na-development" || "$env" == "NA-UAT" || "$env" == "NA-DEVELOPMENT" ]]; then
    env=NA-UAT
    conf=na-uat.json
    market="NA"
fi

if [[ "$env" == "na-sit-tcs" || "$env" == "NA-SIT-TCS" ]]; then
    env=NA-SIT-TCS
    conf=na-sit-tcs.json
    market="NA"
fi

if [[ "$env" == "na-sit2" || "$env" == "NA-SIT2" ]]; then
    env=NA-SIT2
    conf=na-sit2.json
    market="NA"
    market="NA"
fi

if [[ "$env" == "na-sit" || "$env" == "NA-SIT" ]]; then
    env=NA-SIT
    conf=na-sit.json
    market="NA"
fi

if [[ "$env" == "eu-stg" || "$env" == "eu-staging" || "$env" == "EU-STG" || "$env" == "EU-STAGING" ]]; then
    env=EU-STG
    conf=eu-stg.json
    market="EU"
fi

if [[ "$env" == "eu-uat" || "$env" == "eu-development" || "$env" == "EU-UAT" || "$env" == "EU-DEVELOPMENT" ]]; then
    env=EU-UAT
    conf=eu-uat.json
    market="EU"
fi

if [[ "$env" == "eu-sit-tcs" || "$env" == "EU-SIT-TCS" ]]; then
    env=EU-SIT-TCS
    conf=eu-sit-tcs.json
    market="EU"
fi

if [[ "$env" == "eu-sit" || "$env" == "EU-SIT" ]]; then
    env=EU-SIT
    conf=eu-sit.json
    market="EU"
fi

conf=CONF/$conf
if [ ! -f "$conf" ]; then
    echo "Missing ENV config ($conf) file"
    exit 1
fi

dw_hostname=`readJson $conf dw_hostname` || exit 1;
dw_username=`readJson $conf dw_username` || exit 2;
dw_password=`readJson $conf dw_password` || exit 3;
p12=`readJson $conf p12` || exit 4;
passphrase=`readJson $conf passphrase` || exit 5;
dw_version=`readJson $conf dw_version` || exit 6;
git_branch=`readJson $conf git_branch` || exit 7;

DATE_WITH_TIME=`date "+%Y%m%d.%H%M%S"` #add %3N as we want millisecond too
rootDir=/system/SFCC-DEPLOY
envDir=/system/SOURCE.SFCC
cartridgesDir=$envDir/cartridges
gitDir=$envDir/.git
changedDir=$gitDir/.changed
srcPath=
if [ "$srcPath" == "" ]; then
  sourceDir=$envDir
else
  sourceDir=$envDir/$srcPath
fi

mkdir -p $changedDir;
changedFile=$changedDir/$env.$DATE_WITH_TIME.txt;
#deletedFile=$changedDir/deploy.$DATE_WITH_TIME.del;
COLUMNS=211

cd $sourceDir
#cd $sourceDir && echo "10.21" > .nvmrc
nvm use


echo -e "\n${LIGHTGREEN}> Deploying...............................${NOCOLOR}"
echo -e "${LIGHTGREEN}> git branch: ${NOCOLOR}[${YELLOW}$git_branch${NOCOLOR}]"
echo -e "${LIGHTGREEN}> code version: ${NOCOLOR}[${YELLOW}$dw_version${NOCOLOR}]"
echo -e "${LIGHTGREEN}> sandbox: ${NOCOLOR}${YELLOW}${dw_hostname}${NOCOLOR}\n"


cartridgesXML=0
if [[ "$cartridges" == "2" || $cartridges == 2 ]]; then
	cartridges=1
	cartridgesXML=1
fi


diffBranch=$git_branch
if [[ "$market" == "EU" ]]; then
	diffBranch=master-eu
else
    diffBranch=master
fi

CONFLICTS=$(git ls-files -u | wc -l)
if [ "$CONFLICTS" -gt 0 ] ; then
    echo "There is a merge conflict. Aborting"
    git merge --abort
    git checkout -f .
    git clean -fd .
    git clean -fxd $cartridgesDir
    git stash
    git reset --hard d9cd652
else
    git clean -fd . && git clean -fxd $cartridgesDir && git checkout . -f
fi

git fetch origin $git_branch && git checkout $git_branch

#git checkout $git_branch 2>/dev/null || git checkout $diffBranch && git checkout -b $git_branch

# if [[ `git rev-parse --verify $git_branch 2>/dev/null` ]]; then
#   echo "> switch to branch: $git_branch"
#   echo $(git checkout $git_branch)
# else
#   echo "> switch to new branch: $git_branch"
#   echo $(git fetch origin $git_branch && git checkout $git_branch)
# fi


if [[ "$cartridges" == "1" || $cartridges == 1 ]]; then
    echo "> git diff origin/$git_branch origin/$diffBranch --stat=$COLUMNS --name-only > $changedFile"
    echo $(git diff origin/$git_branch origin/$diffBranch --stat=$COLUMNS --name-only > $changedFile)
else
    echo "> git diff $git_branch origin/$git_branch --stat=$COLUMNS --name-only > $changedFile"
    #echo $(git diff $git_branch origin/$git_branch --stat=$COLUMNS --name-only > $changedFile)
    echo $(git diff origin/$(git rev-parse --abbrev-ref HEAD) --stat=$COLUMNS --name-only > $changedFile)
    #git diff origin/$(git rev-parse --abbrev-ref HEAD) --stat=$COLUMNS --name-only > $changedFile
fi

git pull

CONFLICTS=$(git ls-files -u | wc -l)
if [ "$CONFLICTS" -gt 0 ] ; then
   echo "---------------------------------------------------"
   echo -e "\n${LIGHTRED}Automatic merge failed; Aborting${NOCOLOR}\n"
   echo "---------------------------------------------------"
   git merge --abort
   git checkout -f .
   git clean -fd .
   git clean -fxd $cartridgesDir
   git stash
   exit 1
fi

if [ "$passphrase" != "" ]; then
  printf '{\n    "hostname":"%s",\n    "username":"%s",\n    "password":"%s",\n    "code-version":"%s",\n    "p12":"%s",\n    "passphrase":"%s"\n}\n' "$dw_hostname" "$dw_username" "$dw_password" "$dw_version" "$p12" "$passphrase" > $sourceDir/dw.json
else
  printf '{\n    "hostname":"%s",\n    "username":"%s",\n    "password":"%s",\n    "code-version":"%s"\n}\n' "$dw_hostname" "$dw_username" "$dw_password" "$dw_version" > $sourceDir/dw.json
fi

# foundPackage=`npm list | grep -c 'sgmf-scripts'`
# if [ $foundPackage -eq 0 ]; then
#   cd $sourceDir && npm i cleave.js && npm install
#   unzip sfra-webpack-builder.zip && cd sfra-webpack-builder && npm install
#   cd ../ && cp -r sfra-webpack-builder/node_modules/ . && cp -r sfra-webpack-builder node_modules/
# fi

compile=0
compileJS=0
compileCSS=0

if [[ `egrep "(.*)/client/default/js/(.*).js" $changedFile` || `egrep "(.*)/client/default/scss/(.*).scss" $changedFile` ]]; then
	compile=1
	if [[ `egrep "(.*)/client/default/js/(.*).js" $changedFile` ]]; then
	    compileJS=1
	fi
	if [[ `egrep "(.*)/client/default/scss/(.*).scss" $changedFile` ]]; then
	    compileCSS=1
	fi
fi

if [[ "$compile" == "1" || $compile == 1 || "$cartridges" == "1" || $cartridges == 1 ]]; then
	if [[ "$env" == "EU-STG" || "$env" == "NA-STG" ]]; then
	  npm run webpack:prod
	else
	  npm run webpack:dev
	fi
fi

cd $sourceDir && rm -f lib/cartridge.js && cp ../cartridge.js lib/cartridge.js
git update-index --assume-unchanged lib/cartridge.js

#cd $cartridgesDir && zip -rq cartridges.zip .
#npm run upload:all


if [ -f "$rootDir/sfcc_console.zip" ]; then
    rm -f $cartridgesDir/sfcc_console.zip && cp $rootDir/sfcc_console.zip $cartridgesDir/
    cd $cartridgesDir
    unzip -qq sfcc_console.zip
    #if [[ "$env" == "EU-STG" || "$env" == "NA-STG" ]]; then
    #    rm -rf sfcc_console
    #fi
fi

cd $cartridgesDir
for directory in `find . -type d -maxdepth 1 -mindepth 1 -not -name .svn`
do
    cd $cartridgesDir
    dir=`basename $directory`
    replace=$cartridgesDir/
  
    if [[ "$cartridges" == "1" || $cartridges == 1 ]]; then
        #echo -e "\n> ${LIGHTCYAN}Uploading cartridge: ${NOCOLOR}$dir${NOCOLOR}"
        zip -rq $dir.zip $dir
        cd ../ && npm run upload:all $dir
        continue
    fi
    
    
    if [[ `egrep "(.*)/client/default/js/fca.js" $changedFile` && $dir == "app_custom_vinfast_eu" ]]; then
        echo -e "\n> ${LIGHTCYAN}Uploading cartridge: ${NOCOLOR}$dir${NOCOLOR}"
        zip -rq $dir.zip $dir
        cd ../ && npm run upload:all $dir
        continue
    fi
    
    
    if [[ `egrep "$dir/(.*)/client/default/scss/(.*).scss" $changedFile` || `egrep "$dir/(.*)/client/default/scss/(.*).scss" $changedFile` ]]; then
       if [[ $dir == "app_custom_vinfast_ui" ]]; then
            echo -e "\n> ${LIGHTCYAN}Uploading cartridge: ${NOCOLOR}$dir${NOCOLOR}"
            zip -rq $dir.zip $dir
            cd ../ && npm run upload:all $dir
            continue
        fi
    fi


    cartridgeDir=$cartridgesDir/$dir
    if grep "$dir/" $changedFile
    then

        cd $cartridgesDir
        rm -f $cartridgesDir/dw.json && cp $sourceDir/dw.json $cartridgesDir/dw.json

        # Upload file changed to dwupload
        uploadFileCmd=dwupload
        deletedFileCmd=dwupload
        uploadFileNum=0
        deletedFileNum=0
        while IFS= read -r line; do
            if [[ "$srcPath" != "" ]]; then
              srcPathReplace="$srcPath/"
              line=${line//$srcPathReplace/}
            fi
            if [[ $line == *"$dir/"* ]]; then
              uploadFileFullPath=$sourceDir/$line
              uploadFilePath=${uploadFileFullPath//$replace/}
              
			  if [[ $line != *"client/default/js"* ]] && [[ $line != *"client/default/scss"* ]]; then
				  if [[ -f "$uploadFileFullPath" ]]
				  then
					  uploadFileNum=$((uploadFileNum + 1))
					  uploadFileCmd="$uploadFileCmd --file $uploadFilePath"
				  else
					  deletedFileNum=$((deletedFileNum + 1))
					  deletedFileCmd="$deletedFileCmd delete --file $uploadFilePath"
				  fi
              fi

              if [[ $uploadFileNum == 30 ]]
              then
                  cd $cartridgesDir && dwupload $uploadFileCmd
                  uploadFileNum=0
                  uploadFileCmd=dwupload
              fi

              if [[ $deletedFileNum == 30 ]]
              then
                  cd $cartridgesDir && dwupload $deletedFileCmd
                  deletedFileNum=0
                  deletedFileCmd=dwupload
              fi
            fi
        done < $changedFile

        if [[ $uploadFileCmd != "dwupload" ]]
        then
            cd $cartridgesDir && dwupload $uploadFileCmd
        fi

        if [[ $deletedFileCmd != "dwupload" ]]
        then
            cd $cartridgesDir && dwupload $deletedFileCmd
        fi
        # Upload file changed to dwupload

        # Upload static file js/css to dwupload
        #-------------------------------------------------------------
        thisDirCompileJS=`egrep "$dir/(.*)/client/default/js/(.*).js" $changedFile`
        if [[ $thisDirCompileJS || "$compileJS" == "1" ]]; then
            cd $cartridgeDir

            shopt -s globstar
            uploadFileCmd=dwupload
            uploadFileNum=0
            for file in $cartridgeDir/**/static/default/js/*.js; 
            do
                uploadFileNum=$((uploadFileNum + 1))
                uploadFilePath=${file//$replace/}
                uploadFileCmd="$uploadFileCmd --file $uploadFilePath"

                if [[ $uploadFileNum == 30 ]]
                then
                    cd $cartridgesDir && dwupload $uploadFileCmd
                    uploadFileNum=0
                    uploadFileCmd=dwupload
                fi
            done

            if [[ $uploadFileCmd != "dwupload" ]]
            then
                cd $cartridgesDir && dwupload $uploadFileCmd
            fi
        fi

        #-------------------------------------------------------------
        thisDirCompileCSS=`egrep "$dir/(.*)/client/default/scss/(.*).scss" $changedFile`
        if [[ $thisDirCompileCSS || "$compileCSS" == "1" ]]; then
            cd $cartridgeDir

            shopt -s globstar
            uploadFileCmd=dwupload
            uploadFileNum=0
            for file in $cartridgeDir/**/static/default/css/**/*.css; 
            do
                uploadFileNum=$((uploadFileNum + 1))
                uploadFilePath=${file//$replace/}
                uploadFileCmd="$uploadFileCmd --file $uploadFilePath"

                if [[ $uploadFileNum == 30 ]]
                then
                    cd $cartridgesDir && dwupload $uploadFileCmd
                    uploadFileNum=0
                    uploadFileCmd=dwupload
                fi
            done

            if [[ $uploadFileCmd != "dwupload" ]]
            then
                cd $cartridgesDir && dwupload $uploadFileCmd
            fi
        fi
        #-------------------------------------------------------------
        # Upload static file js/css to dwupload

    fi

  rm -f $cartridgesDir/dw.json
done



echo -e "\n${YELLOW}-------------------------------------------------------------${NOCOLOR}\n"

#-------------------------------------------------------------
# BEGIN upload impex xml
#-------------------------------------------------------------

if [[ "$cartridgesXML" == "1" || $cartridgesXML == 1 ]]; then
    $xmlChangedFile=$changedDir/$env.$DATE_WITH_TIME.cartridgesXML.txt;
    if [[ "$market" == "EU" ]]; then
        echo "data_eu/meta/custom-objecttype-definitions.xml" >> $xmlChangedFile
        echo "data_eu/meta/system-objecttype-extensions.xml" >> $xmlChangedFile
        echo "data_eu/sites/VinfastEU/library/library.xml" >> $xmlChangedFile
        echo "data_eu/catalogs/vf-catalog/catalog.xml" >> $xmlChangedFile
        echo "data_eu/inventory-lists/vinfast_eu_inventory.xml" >> $xmlChangedFile
        echo "data_eu/pricebooks/de_DE-list-prices.xml" >> $xmlChangedFile
        echo "data_eu/pricebooks/fr_FR-list-prices.xml" >> $xmlChangedFile
        echo "data_eu/pricebooks/nl_NL-list-prices.xml" >> $xmlChangedFile
    else
        echo "data/meta/custom-objecttype-definitions.xml" >> $xmlChangedFile
        echo "data/meta/system-objecttype-extensions.xml" >> $xmlChangedFile
        echo "data/sites/Vinfast-US/library/library.xml" >> $xmlChangedFile
        echo "data/sites/Vinfast-CA/library/library.xml" >> $xmlChangedFile
        echo "data/catalogs/vinfast-catalog-us/catalog.xml" >> $xmlChangedFile
        echo "data/catalogs/vinfast-catalog-ca/catalog.xml" >> $xmlChangedFile
        echo "data/inventory-lists/vf-us-inventory-list.xml" >> $xmlChangedFile
        echo "data/inventory-lists/vf-ca-inventory-list.xml" >> $xmlChangedFile
        echo "data/pricebooks/vinfast-ca-list-price.xml" >> $xmlChangedFile
        echo "data/pricebooks/vinfast-us-list-price.xml" >> $xmlChangedFile
        echo "data/pricebooks/vinfast-us-prices-with-battery.xml" >> $xmlChangedFile
    fi
    
    /system/impex_uploader.sh --dw_hostname $dw_hostname --dw_username $dw_username --dw_password $dw_password --p12 $p12 --passphrase $passphrase --envDir $envDir --datetime $DATE_WITH_TIME --market $market --changedFile $xmlChangedFile

elif [[ `egrep "data/(.*)/(.*).xml" $changedFile` || `egrep "data_eu/(.*)/(.*).xml" $changedFile` ]]; then
	/system/impex_uploader.sh --dw_hostname $dw_hostname --dw_username $dw_username --dw_password $dw_password --p12 $p12 --passphrase $passphrase --envDir $envDir --datetime $DATE_WITH_TIME --market $market --changedFile $changedFile
fi

#-------------------------------------------------------------
# END upload impex xml
#-------------------------------------------------------------


cd $sourceDir && git clean -fd . && git clean -fxd $cartridgesDir && git checkout . -f

echo -e "\n${LIGHTGREEN}Deploy success to${NOCOLOR} ${YELLOW}${dw_hostname}${NOCOLOR}\n"
