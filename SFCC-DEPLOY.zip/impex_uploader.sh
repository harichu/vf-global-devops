#!/bin/bash

# ----------------------------------
# Colors
# ----------------------------------
NOCOLOR='\033[0m'
RED='\033[0;31m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHTGRAY='\033[0;37m'
DARKGRAY='\033[1;30m'
LIGHTRED='\033[1;31m'
LIGHTGREEN='\033[1;32m'
YELLOW='\033[1;33m'
LIGHTBLUE='\033[1;34m'
LIGHTPURPLE='\033[1;35m'
LIGHTCYAN='\033[1;36m'
WHITE='\033[1;37m'
# ----------------------------------

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --dw_hostname) dw_hostname="$2"; shift ;;
        --dw_username) dw_username="$2"; shift ;;
        --dw_password) dw_password="$2"; shift ;;
        --p12) p12="$2"; shift ;;
        --passphrase) passphrase="$2"; shift ;;
        --envDir) envDir="$2"; shift ;;
        --changedFile) changedFile="$2"; shift ;;
        --datetime) datetime="$2"; shift ;;
        --market) market="$2"; shift ;;
        *) echo "Unknown parameter passed: $1";
    esac
    shift
done

basic_auth=`echo -n "$dw_username:$dw_password" | base64`
basic_auth=`echo ${basic_auth} | tr -d '\n'`


while IFS= read -r line; do
    if [[ $line == "" || $line != *".xml"* ]]; then
      continue
    fi
    if [[ $line == *"sites/Vinfast-US"* || $line == *"vinfast-catalog-us"* || $line == *"vf-us-inventory-list"* || $line == *"vinfast-us-list-price"* || $line == *"vinfast-us-prices-with-battery"* ]]; then
      market=US
    elif [[ $line == *"sites/Vinfast-CA"* || $line == *"vinfast-catalog-ca"* || $line == *"vf-ca-inventory-list"* || $line == *"vinfast-ca-list-price"* ]]; then
      market=CA
    fi
    
    if [[ $line == *"/catalogs/"* ]]; then
      impex_src=catalog
    elif [[ $line == *"/inventory-lists/"* ]]; then
      impex_src=catalog
    elif [[ $line == *"/pricebooks/"* ]]; then
      impex_src=catalog
    elif [[ $line == *"/custom-objects/"* ]]; then
      impex_src=customobject
    elif [[ $line == *"/library/"* ]]; then
      impex_src=library
    elif [[ $line == *"/meta/"* ]]; then
      impex_src=customization
    elif [[ $line == *"stores.xml"* ]]; then
      impex_src=marketing
    elif [[ $line == *"store.xml"* ]]; then
      impex_src=marketing
    elif [[ $line == *"sourcecodes.xml"* ]]; then
      impex_src=marketing
    else
      impex_src=
    fi
    
    fullfile=$envDir/$line

    filename=$(basename -- "$fullfile")
    extension="${filename##*.}"
    filename="${filename%.*}"
    
    if [[ $impex_src == '' ]]; then
      echo -e "\n${LIGHTRED}Undefined impex_src for xml file: ${NOCOLOR}$filename.$extension${NOCOLOR}"
      continue
    fi
    
    
    if [[ $p12 != "" && $p12 != "--passphrase" ]]; then
        run=`curl --insecure --cert-type P12 --cert $p12:$passphrase --silent --location --request PUT "https://$dw_hostname/on/demandware.servlet/webdav/Sites/Impex/src/$impex_src/$datetime.$market-$filename.$extension" --header "authorization: Basic $basic_auth" --data-binary "@/$fullfile"`
    else
        run=`curl --silent --location --request PUT "https://$dw_hostname/on/demandware.servlet/webdav/Sites/Impex/src/$impex_src/$datetime.$market-$filename.$extension" --header "authorization: Basic $basic_auth" --data-binary "@/$fullfile"`
    fi
    
    
    echo -e "\n${LIGHTCYAN}Successfully uploaded xml: ${NOCOLOR}$datetime.$market-$filename.$extension${NOCOLOR}"
    
done < $changedFile
