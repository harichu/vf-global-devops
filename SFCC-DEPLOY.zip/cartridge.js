'use strict';

require('shelljs/make');

const chalk = require('chalk');
const chokidar = require('chokidar');
const DWDAV = require('dwdav');
const fs = require('fs');
const path = require('path');
const shell = require('shelljs');
const _ = require('lodash');

const cwd = process.cwd();
const dw = require(path.join(cwd, 'dw.json'));
const dwdav = DWDAV(_.extend(dw, {
    version: dw['code-version'],
    root: './cartridges'
}));

function uploadCartridges(path) {
    fs.readdir(path, function(err, files) {
        var i;
        for (i = 0; i < files.length; i++) {
            if (fs.statSync(path + files[i]).isDirectory()) {
                console.log(chalk.green('uploading ' + files[i] + ' cartridge'));
                shell.exec('sgmf-scripts --uploadCartridge ' + files[i]);
                console.log(chalk.green('finished uploading ' + files[i] + ' cartridge'));
            }
        }
    });
}

function deleteFile(filePath) {
    dwdav.delete(filePath)
        .then(function() {
            console.log(chalk.green('deleted: ' + filePath));
        });
}

function uploadFile(filePath) {
    dwdav.delete(filePath)
        .then(function() {
            return dwdav.post(filePath);
        }).then(function() {
            console.log(chalk.green('uploaded: ' + filePath));
        });
}

target.uploadAll = function() {
    const myArgs = process.argv.slice(2);
    var cartridge = (myArgs[1]) ? myArgs[1] : 'cartridges';
    var path = './cartridges/';
    var filePath = path + cartridge + '.zip';
    try {
        //console.log(chalk.green('uploading ' + cartridge + ' cartridge'));
        dwdav.postAndUnzip(filePath)
            .then(function() {
                dwdav.delete(filePath);
                fs.unlink(filePath, (err => {
                    if (err) console.log(err);
                }));
                console.log(chalk.green('> Successfully uploaded cartridge: ' + cartridge + ''));
            }).catch(err => console.log(err));
    } catch (e) {
        console.log(chalk.red('error uploading all cartridges: ' + e));
    }
};

target.uploadChanges = function() {
    const watcher = chokidar.watch(path.join(cwd, 'cartridges'), {
        ignored: [
            '**/cartridge/js/**',
            '**/cartridge/client/**',
            '**/*.scss'
        ],
        persistent: true,
        ignoreInitial: true,
        followSymlinks: false,
        awaitWriteFinish: {
            stabilityThreshold: 300,
            pollInterval: 100
        }
    });

    console.log(chalk.gray('Watching files...'));

    watcher.on('change', file => {
        const relativePath = path.relative(cwd, file);
        console.log(chalk.gray(`file changed: ${relativePath}`));
        uploadFile(relativePath);
    });

    watcher.on('add', file => {
        const relativePath = path.relative(cwd, file);
        console.log(chalk.gray(`file added: ${relativePath}`));
        uploadFile(relativePath);
    });

    watcher.on('unlink', file => {
        const relativePath = path.relative(cwd, file);
        console.log(chalk.gray(`file deleted: ${relativePath}`));
        deleteFile(relativePath);
    });
};