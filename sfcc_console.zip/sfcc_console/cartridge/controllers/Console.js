'use strict';

var system = require('dw/system/System');
var LoggerX = require('dw/system/Logger').getLogger('Console', '');
var SecurityHelpers = require('*/cartridge/scripts/helpers/securityHelpers');
var customerHelpers = require('*/cartridge/scripts/helpers/customerHelper');

/**
 * Run the script and return the response
 */
function Run() {
    SecurityHelpers.addSecurityHeaders();
    if (request.httpMethod !== 'POST') {
        return sendJSON({
            error: true,
            message: 'Method Not Allowed.'
        }, 405);
    }
    
    if (system.PRODUCTION_SYSTEM === system.getInstanceType()) {
        var Authorization = (request.httpHeaders['authorization'] || '').replace('Basic ', '');
        if (empty(Authorization) || Authorization === '') {
            return sendJSON({
                error: true,
                message: 'Authorization is missing.'
            }, 400);
        }
        
        var collections = require('*/cartridge/scripts/util/collections');
        var StringUtils = require('dw/util/StringUtils');
        var [authUser, authPass] = (StringUtils.decodeBase64(Authorization)).split(':');
        var ipAddress = request.getHttpRemoteAddress();
        
        var accountHelpers = require('*/cartridge/scripts/auth0/helpers/accountHelpers');
        var customerLoginResult = accountHelpers.loginCustomer(authUser, authPass, false, ipAddress);
        
        if (customerLoginResult.error) {
            return sendJSON({
                error: true,
                message: customerLoginResult.errorMessage
            }, 401);
        }
        if (!customerLoginResult.authenticatedCustomer) {
            return sendJSON({
                error: true,
                message: 'Unauthorized.'
            }, 401);
        }
        
        const currentCustomer = customerHelpers.getCustomerByEmail(authUser);
        const adminGroupID = 'ITAdmin';
        var customerGroup = collections.map(currentCustomer.getCustomerGroups(), function (value) {
            return value.ID;
        });
        if (customerGroup.indexOf(adminGroupID) === -1) {
            return sendJSON({
                error: true,
                message: 'your account does not have the required privilege to access this feature.'
            }, 403);
        }
    }
    
    var code = request.httpParameterMap.requestBodyAsString;
    var maxDepth = parseInt(request.httpHeaders['maxdepth'] || 3);
    
    // if missing max depth or code return and do nothing, send no response
    if (!code || !maxDepth) {
        return sendJSON({
            error: true,
            message: 'payload is empty.'
        }, 400);
    }
    
    var result;
    var startTime = new Date();
    var logs = new dw.util.ArrayList();

    LoggerX.warn('\n{0}', code);
    try {
        var myFunc = new Function('log', code);
        result = myFunc(function (arg) {
            logs.add(arg);
        });
    } catch (e) {
        result = e;
    }
    
    var runtime = new Date().getTime() - startTime.getTime();
    
    var serializer = require('../scripts/serializer');
    result = serializer.serialize(result, maxDepth);
    logs = serializer.serialize(logs, maxDepth);
    
    if (typeof result === 'string' || typeof result === 'boolean' || typeof result === 'number') {
        return sendJSON({ logs: logs, result: [result], executionTime: runtime });
    }
    
    sendJSON({ logs: logs, result: result || {}, executionTime: runtime });
}

/**
 * Helper to send a json response
 *
 * @param content
 * @param status
 */
function sendJSON(content, status) {
    response.setStatus(status || 200);
    response.setContentType('application/json');
    response.getWriter()
        .print(JSON.stringify(content));
}

module.exports.Run = Run;
module.exports.Run.public = true;
