'use strict';

var CustomerMgr = require('dw/customer/CustomerMgr');
var Logger = require('dw/system/Logger').getLogger('customer', '');
var Transaction = require('dw/system/Transaction');
var CustomObjectMgr = require('dw/object/CustomObjectMgr');

/**
 * getExternallCustomerByEmail
 * @param {string} email
 * @returns {dw.customer.Customer}
 */

function getExternallCustomerByEmail(email) {
    var customerNo, tempCustomer;
    var customer,
        profile,
        profiles = CustomerMgr.queryProfiles('email ILIKE {0}', "lastLoginTime DESC", email);
    while (profiles.hasNext()) {
        profile = profiles.next();
        if (profile && profile.getCredentials().isEnabled() && profile.email !== 'undefined' && emailFormatter(profile.email) === emailFormatter(email)) {
            tempCustomer = profile.getCustomer();
            if (profile.getCustomer().getOrderHistory().getOrderCount() > 0) {
                if (profile.custom.serviceCloudAccountId) {
                    customer = profile.getCustomer();
                    customerNo = profile.customerNo;
                }
            }
        }
    }
    profiles.close();
    if (empty(customer)) customer = tempCustomer;
    return customer;
}

/**
 * getExternallProfile
 * @param {string} email
 * @returns {dw.customer.Profile|null}
 */

function getExternallProfile(email) {
    var customer = getExternallCustomerByEmail(email);
    if (customer) {
        return customer.getProfile();
    }
    return null;
}

/**
 * getCustomerByEmail
 * @param {string} email
 * @returns {dw.customer.Customer}
 */

function getCustomerByEmail(email) {
    var customer = CustomerMgr.getCustomerByLogin(email);
    if (empty(customer) || customer.getProfile().getCredentials().isEnabled() === false) {
        customer = getExternallCustomerByEmail(email);
    }
    return customer;
}

/**
 * getCustomerByCustomerNo
 * @param {string} customerNo
 * @returns {dw.customer.Customer|*}
 */

function getCustomerByCustomerNo(customerNo) {
    if (empty(customerNo)) return customerNo;
    return CustomerMgr.getCustomerByCustomerNumber(customerNo);
}

/**
 * cleanName
 * @param {string} customerName
 * @returns {string|*}
 */

function cleanName(customerName) {
    if (empty(customerName)) return customerName;
    if (typeof customerName !== 'string') return customerName;
    customerName = customerName.replace(/\s\s+/, ' ');
    customerName = customerName.replace(/\t+/, ' ');
    customerName = customerName.trim();
    return customerName;
}

/**
 * validateEmail
 * @param {string} email
 * @returns {boolean}
 */

function validateEmail(email) {
    if (empty(email)) return false;
    if (typeof email !== 'string') return false;
    var regexEmail = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regexEmail.test(email);
}

/**
 * emailFormatter
 * @param {string} email
 * @returns {string|*}
 */

function emailFormatter(email) {
    if (empty(email)) return email;
    if (typeof email !== 'string') return email;
    email = email.toLowerCase();
    email = email.trim();
    return email;
}

module.exports = {
    getExternallCustomerByEmail: getExternallCustomerByEmail,
    getCustomerByEmail: getCustomerByEmail,
    getExternallProfile: getExternallProfile,
    getCustomerByCustomerNo: getCustomerByCustomerNo,
    emailFormatter: emailFormatter,
    validateEmail: validateEmail,
    cleanName: cleanName
};
