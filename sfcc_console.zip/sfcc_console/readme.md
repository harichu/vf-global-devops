### postman here

```shell
curl -L -X POST 'https://bhgw-003.sandbox.us01.dx.commercecloud.salesforce.com/on/demandware.store/Sites-VinfastEU-Site/default/Console-Run' \
-H 'Authorization: Basic aGFpY3YzQGhvdG1haWwucmVkOlZobUAxMjM0NQ==' \
-H 'Content-Type: application/javascript' \
--data-raw 'return session;'
```